"use client";
import Link from "next/link";
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode, type MouseEvent } from "react";
import { LANGS, getT, type Content, type T } from "@/lib/defaults";
import { Icon, SocialPaths, WhatsAppIcon } from "./Icons";

export type PageKey = "home" | "about" | "services" | "projects" | "contact";
type Ctx = { c: Content; t: T; lang: string; setLang: (l: string) => void; rtl: boolean };
const SiteCtx = createContext<Ctx | null>(null);
const useSite = () => useContext(SiteCtx)!;

const SERVICE_ICONS = ["building", "home", "office", "bridge", "tools", "clipboard"];
const WHY_ICONS = ["medal", "users", "shield", "thumb", "clock", "heart"];
const STEP_ICONS = ["chat", "pencil", "crane", "check"];

/* ---------------- helpers ---------------- */
function Tilt({ children, className = "", max = 12 }: { children: ReactNode; className?: string; max?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const move = (e: MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `perspective(1000px) rotateY(${x * max}deg) rotateX(${-y * max}deg) scale(1.03)`;
  };
  const leave = () => ref.current && (ref.current.style.transform = "");
  return (
    <div ref={ref} onMouseMove={move} onMouseLeave={leave} className={`tilt ${className}`}>
      {children}
    </div>
  );
}

function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [n, setN] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    const io = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting) return;
      io.disconnect();
      const start = performance.now();
      const tick = (now: number) => {
        const p = Math.min(1, (now - start) / 2000);
        setN(Math.round(to * (1 - Math.pow(1 - p, 3))));
        if (p < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    });
    io.observe(el);
    return () => { io.disconnect(); cancelAnimationFrame(raf); };
  }, [to]);
  return <span ref={ref}>{n.toLocaleString()}{suffix}</span>;
}

function Logo({ light = false }: { light?: boolean }) {
  const { c } = useSite();
  return (
    <Link href="/" className="flex items-center gap-2 sm:gap-2.5 min-w-0 shrink">
      {c.settings.logo ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={c.settings.logo} alt={c.settings.companyName} className="h-9 sm:h-11 w-auto max-w-[120px] object-contain shrink-0" />
      ) : (
        <svg viewBox="0 0 48 48" className="h-9 w-9 sm:h-11 sm:w-11 shrink-0">
          <defs><linearGradient id="lg" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stopColor="#ffd56b" /><stop offset="1" stopColor="#e8901a" /></linearGradient></defs>
          <path d="M6 44V14l8-5v35zM18 44V6l8-4v42zM30 44V20h-4v-6h16v30h-6V26h-6z" fill="url(#lg)" />
        </svg>
      )}
      <div className="leading-tight min-w-0">
        <div className={`font-extrabold tracking-wide text-sm sm:text-lg truncate ${light ? "text-white" : "text-main"}`}>{c.settings.companyName}</div>
        <div className="text-[7px] sm:text-[9px] font-semibold tracking-[.12em] sm:tracking-[.25em] text-gold truncate">{c.settings.companySub}</div>
      </div>
    </Link>
  );
}

function SectionHead({ kicker, title, text, center = false, light = false }: { kicker: string; title: string; text?: string; center?: boolean; light?: boolean }) {
  return (
    <div className={`reveal mb-12 ${center ? "text-center mx-auto max-w-2xl" : "max-w-xl"}`}>
      <div className="kicker">{kicker}</div>
      <h2 className={`mt-3 text-3xl md:text-5xl font-extrabold leading-tight ${light ? "text-white" : "text-main"}`}>{title}</h2>
      {text && <p className={`mt-4 text-base md:text-lg ${light ? "text-white/75" : "text-muted"}`}>{text}</p>}
    </div>
  );
}

/* ---------------- Navbar ---------------- */
function Navbar({ page }: { page: PageKey }) {
  const { t, lang, setLang } = useSite();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    on();
    window.addEventListener("scroll", on);
    setDark(document.documentElement.classList.contains("dark"));
    return () => window.removeEventListener("scroll", on);
  }, []);
  const toggleDark = () => {
    const d = !dark;
    setDark(d);
    document.documentElement.classList.toggle("dark", d);
    localStorage.setItem("ha_theme", d ? "dark" : "light");
  };
  const solid = scrolled || open;
  const links: [PageKey, string, string][] = [["home", "/", t.nav.home], ["about", "/about", t.nav.about], ["services", "/services", t.nav.services], ["projects", "/projects", t.nav.projects], ["contact", "/contact", t.nav.contact]];
  const light = !solid;
  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${solid ? "bg-card backdrop-blur-xl shadow-lg py-2" : "py-4"}`}>
      <div className="mx-auto max-w-7xl px-3 sm:px-4 flex items-center justify-between gap-2 sm:gap-4">
        <Logo light={light} />
        <nav className={`hidden lg:flex items-center gap-1 rounded-full px-2 py-1.5 ${light ? "glass" : ""}`}>
          {links.map(([k, href, label]) => (
            <Link key={k} href={href} className={`relative px-4 py-2 text-sm font-medium rounded-full transition ${page === k ? "text-gold" : light ? "text-white hover:text-gold" : "text-main hover:text-gold"}`}>
              {label}
              {page === k && <span className="absolute left-1/2 -translate-x-1/2 bottom-0.5 h-0.5 w-6 rounded bg-gold" />}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <div className="relative">
            <button onClick={() => setLangOpen(!langOpen)} className={`flex items-center gap-1.5 rounded-full px-2.5 sm:px-3 py-2 text-sm ${light ? "text-white glass" : "text-main border border-line"}`} aria-label="Language">
              <Icon name="globe" /> <span className="hidden sm:inline">{LANGS.find((l) => l.code === lang)?.label}</span>
            </button>
            {langOpen && (
              <div className="absolute end-0 mt-2 w-40 rounded-xl bg-card shadow-2xl border border-line overflow-hidden fade-up">
                {LANGS.map((l) => (
                  <button key={l.code} onClick={() => { setLang(l.code); setLangOpen(false); }} className={`block w-full text-start px-4 py-2.5 text-sm hover:bg-site2 ${lang === l.code ? "text-gold font-semibold" : "text-main"}`}>{l.label}</button>
                ))}
              </div>
            )}
          </div>
          <button onClick={toggleDark} className={`rounded-full p-2 sm:p-2.5 ${light ? "text-white glass" : "text-main border border-line"}`} aria-label="Theme"><Icon name={dark ? "sun" : "moon"} /></button>
          <Link href="/admin" title={t.nav.admin} className={`hidden sm:flex rounded-full p-2 sm:p-2.5 ${light ? "text-white glass" : "text-main border border-line"}`}><Icon name="lock" /></Link>
          <Link href="/contact#form" className="btn-gold hidden md:inline-flex !py-2.5 text-sm">{t.nav.quote} <Icon name="arrow" className="rtl:rotate-180" /></Link>
          <button onClick={() => setOpen(!open)} className={`lg:hidden rounded-full p-2 sm:p-2.5 ${light ? "text-white glass" : "text-main border border-line"}`} aria-label="Menu"><Icon name={open ? "close" : "menu"} /></button>
        </div>
      </div>
      <div className={`lg:hidden overflow-hidden transition-all duration-500 ${open ? "max-h-[500px]" : "max-h-0"}`}>
        <div className="px-4 py-4 flex flex-col gap-1">
          {links.map(([k, href, label]) => (
            <Link key={k} href={href} onClick={() => setOpen(false)} className={`px-4 py-3 rounded-xl font-medium ${page === k ? "bg-gold text-black" : "text-main hover:bg-site2"}`}>{label}</Link>
          ))}
          <Link href="/admin" className="px-4 py-3 rounded-xl text-main hover:bg-site2 flex items-center gap-2"><Icon name="lock" /> {t.nav.admin}</Link>
          <Link href="/contact#form" className="btn-gold justify-center mt-2">{t.nav.quote}</Link>
        </div>
      </div>
    </header>
  );
}

/* ---------------- Hero ---------------- */
function Hero() {
  const { c, t } = useSite();
  const slides = c.images.slides.length ? c.images.slides : [""];
  const [i, setI] = useState(0);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const video = c.settings.heroMode === "video" && c.settings.heroVideo;
  useEffect(() => {
    const id = setInterval(() => setI((p) => (p + 1) % Math.max(slides.length, t.hero.slides.length)), 6500);
    return () => clearInterval(id);
  }, [slides.length, t.hero.slides.length]);
  const s = t.hero.slides[i % t.hero.slides.length];
  return (
    <section
      className="relative h-[100svh] min-h-[640px] overflow-hidden bg-[#0b1f3a]"
      onMouseMove={(e) => setMouse({ x: e.clientX / window.innerWidth - 0.5, y: e.clientY / window.innerHeight - 0.5 })}
    >
      {video ? (
        <video className="absolute inset-0 h-full w-full object-cover" src={c.settings.heroVideo} autoPlay muted loop playsInline poster={slides[0]} />
      ) : (
        slides.map((src, k) => (
          <div key={k} className={`absolute inset-0 transition-opacity duration-[1500ms] ${k === i % slides.length ? "opacity-100" : "opacity-0"}`}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={src} alt="" className={`h-full w-full object-cover ${k === i % slides.length ? "kb" : ""}`} />
          </div>
        ))
      )}
      <div className="absolute inset-0 bg-gradient-to-r from-[#07142a]/90 via-[#0b1f3a]/60 to-transparent rtl:bg-gradient-to-l" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#07142a]/70 via-transparent to-transparent" />
      <div className="absolute inset-0 blueprint opacity-40" />
      {/* decorative 3D rings */}
      <div className="pointer-events-none absolute -end-40 top-1/4 h-[520px] w-[520px] rounded-full border border-[var(--gold)]/30 spin-slow hidden md:block" style={{ transform: `translate(${mouse.x * -30}px, ${mouse.y * -30}px)` }}>
        <div className="absolute inset-10 rounded-full border border-dashed border-white/20" />
        <div className="absolute top-0 left-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold shadow-[0_0_20px_var(--gold)]" />
      </div>

      <div className="relative z-10 mx-auto flex h-full max-w-7xl items-center px-4">
        <div key={i} className="max-w-3xl" style={{ transform: `translate(${mouse.x * 14}px, ${mouse.y * 14}px)` }}>
          <div className="kicker fade-up">{t.hero.kicker}</div>
          <h1 className="mt-5 text-4xl sm:text-6xl lg:text-7xl font-extrabold leading-[1.08] text-white fade-up" style={{ animationDelay: ".15s" }}>
            {s.title}<br /><span className="text-grad">{s.highlight}</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-white/80 max-w-xl fade-up" style={{ animationDelay: ".3s" }}>{s.sub}</p>
          <div className="mt-9 flex flex-wrap gap-4 fade-up" style={{ animationDelay: ".45s" }}>
            <Link href="/projects" className="btn-gold">{t.hero.btn1} <Icon name="arrow" className="rtl:rotate-180" /></Link>
            <Link href="/contact#form" className="btn-ghost">{t.hero.btn2} <Icon name="arrow" className="rtl:rotate-180" /></Link>
          </div>
        </div>
      </div>

      {/* floating stats card */}
      <div className="absolute bottom-28 end-6 z-10 hidden xl:block floaty">
        <Tilt className="glass rounded-2xl p-5 w-64 text-white shadow-2xl">
          <div className="pop flex items-center gap-3">
            <div className="grad-gold h-12 w-12 rounded-xl grid place-items-center text-black text-2xl"><Icon name="crane" /></div>
            <div>
              <div className="text-3xl font-extrabold"><Counter to={c.stats[0]?.value || 0} suffix={c.stats[0]?.suffix} /></div>
              <div className="text-xs text-white/70">{t.stats[0]}</div>
            </div>
          </div>
          <div className="pop mt-4 h-1.5 rounded bg-white/20 overflow-hidden"><div className="h-full w-4/5 grad-gold" /></div>
        </Tilt>
      </div>

      {/* controls */}
      <div className="absolute bottom-8 inset-x-0 z-10 mx-auto max-w-7xl px-4 flex items-center justify-between">
        <div className="flex gap-2">
          {slides.map((_, k) => (
            <button key={k} onClick={() => setI(k)} aria-label={`slide ${k + 1}`} className={`h-2 rounded-full transition-all ${k === i % slides.length ? "w-10 bg-gold" : "w-2 bg-white/50"}`} />
          ))}
        </div>
        <a href="#about" className="flex flex-col items-center gap-2 text-white/80 text-xs">
          <span className="h-9 w-6 rounded-full border-2 border-white/60 flex justify-center pt-1.5"><span className="h-2 w-1 rounded bg-gold scroll-dot" /></span>
          {t.hero.scroll}
        </a>
        <div className="flex gap-2">
          <button onClick={() => setI((p) => (p - 1 + slides.length) % slides.length)} className="glass rounded-full p-3 text-white hover:bg-gold hover:text-black transition"><Icon name="left" className="rtl:rotate-180" /></button>
          <button onClick={() => setI((p) => (p + 1) % slides.length)} className="glass rounded-full p-3 text-white hover:bg-gold hover:text-black transition"><Icon name="right" className="rtl:rotate-180" /></button>
        </div>
      </div>
    </section>
  );
}

function PageHeader({ title, crumb }: { title: string; crumb: string }) {
  const { c, t } = useSite();
  return (
    <section className="relative h-[52vh] min-h-[380px] overflow-hidden bg-[#0b1f3a] flex items-end">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={c.images.cta} alt="" className="absolute inset-0 h-full w-full object-cover kb" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#07142a] via-[#0b1f3a]/70 to-[#0b1f3a]/40" />
      <div className="absolute inset-0 blueprint opacity-50" />
      <div className="relative mx-auto w-full max-w-7xl px-4 pb-16">
        <div className="text-sm text-white/70 fade-up"><Link href="/" className="hover:text-gold">{t.nav.home}</Link> / <span className="text-gold">{crumb}</span></div>
        <h1 className="mt-3 text-4xl md:text-6xl font-extrabold text-white fade-up" style={{ animationDelay: ".15s" }}>{title}</h1>
        <div className="mt-5 h-1 w-24 grad-gold rounded fade-up" style={{ animationDelay: ".3s" }} />
      </div>
    </section>
  );
}

/* ---------------- Sections ---------------- */
function Stats() {
  const { c, t } = useSite();
  return (
    <section className="relative z-20 -mt-16 px-4">
      <div className="mx-auto max-w-6xl grid grid-cols-2 md:grid-cols-4 rounded-3xl bg-card shadow-2xl border border-line overflow-hidden reveal zoom">
        {c.stats.map((s, k) => (
          <div key={k} className="group relative p-6 md:p-8 text-center border-line border-e last:border-e-0 hover:bg-[#0b1f3a] transition-colors duration-500">
            <div className="text-3xl md:text-5xl font-extrabold text-grad"><Counter to={s.value} suffix={s.suffix} /></div>
            <div className="mt-2 text-sm text-muted group-hover:text-white/80">{t.stats[k]}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function About({ full = false }: { full?: boolean }) {
  const { c, t } = useSite();
  const icons = ["medal", "thumb", "shield", "users"];
  return (
    <section id="about" className="py-24 px-4 bg-site overflow-hidden">
      <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-14 items-center">
        <div className="relative reveal left">
          <Tilt max={8} className="relative rounded-3xl overflow-hidden shadow-2xl shine">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={c.images.about} alt="" className="w-full h-[460px] object-cover" />
          </Tilt>
          <div className="absolute -bottom-8 -end-4 md:end-8 bg-[#0b1f3a] text-white rounded-2xl p-6 shadow-2xl floaty">
            <div className="text-4xl font-extrabold text-grad"><Counter to={c.stats[1]?.value || 15} suffix="+" /></div>
            <div className="text-sm text-white/70">{t.stats[1]}</div>
          </div>
          <div className="absolute -top-6 -start-6 h-32 w-32 rounded-3xl border-4 border-[var(--gold)] -z-10" />
        </div>
        <div>
          <SectionHead kicker={t.about.kicker} title={t.about.title} text={t.about.text} />
          <div className="grid grid-cols-2 gap-4">
            {t.about.points.map((p, k) => (
              <div key={k} className="reveal flip group rounded-2xl border border-line bg-card p-5 hover:border-[var(--gold)] card-hover" style={{ transitionDelay: `${k * 100}ms` }}>
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-xl bg-[var(--gold)]/15 text-gold grid place-items-center text-2xl group-hover:grad-gold group-hover:text-black transition"><Icon name={icons[k % 4]} /></div>
                  <div><div className="text-2xl font-extrabold text-main">{p.v}</div><div className="text-xs text-muted">{p.l}</div></div>
                </div>
              </div>
            ))}
          </div>
          {!full && <Link href="/about" className="btn-outline mt-8 reveal">{t.nav.about} <Icon name="arrow" className="rtl:rotate-180" /></Link>}
        </div>
      </div>
      {full && (
        <div className="mx-auto max-w-7xl mt-24 grid md:grid-cols-3 gap-6">
          {([["missionTitle", "mission", "crane"], ["visionTitle", "vision", "globe"], ["valuesTitle", "values", "heart"]] as const).map(([a, b, ic], k) => (
            <div key={a} className="flip-card h-64 reveal" style={{ transitionDelay: `${k * 120}ms` }}>
              <div className="flip-inner">
                <div className="flip-face bg-card border border-line p-8 flex flex-col justify-center items-center text-center">
                  <div className="grad-gold h-16 w-16 rounded-2xl grid place-items-center text-3xl text-black"><Icon name={ic} /></div>
                  <h3 className="mt-5 text-2xl font-bold text-main">{t.about[a]}</h3>
                </div>
                <div className="flip-face flip-back bg-[#0b1f3a] text-white p-8 flex flex-col justify-center text-center">
                  <h3 className="text-xl font-bold text-gold">{t.about[a]}</h3>
                  <p className="mt-3 text-white/80">{t.about[b]}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function Services({ full = false }: { full?: boolean }) {
  const { c, t } = useSite();
  return (
    <section className="py-24 px-4 bg-site2 relative overflow-hidden">
      <div className="absolute inset-0 blueprint opacity-60" />
      <div className="relative mx-auto max-w-7xl">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead kicker={t.services.kicker} title={t.services.title} text={t.services.text} />
          {!full && <Link href="/services" className="btn-outline mb-12 reveal">{t.services.all} <Icon name="arrow" className="rtl:rotate-180" /></Link>}
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {t.services.items.map((s, k) => (
            <div key={k} className="reveal flip" style={{ transitionDelay: `${(k % 3) * 120}ms` }}>
              <Tilt className="group relative h-full rounded-3xl bg-card border border-line overflow-hidden shadow-lg">
                <div className="relative h-56 overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={c.images.services[k % c.images.services.length]} alt={s.title} className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b1f3a]/80 to-transparent" />
                  <span className="absolute top-4 end-4 text-5xl font-extrabold text-white/25">0{k + 1}</span>
                </div>
                <div className="pop relative p-6">
                  <div className="absolute -top-8 start-6 grad-gold h-14 w-14 rounded-2xl grid place-items-center text-2xl text-black shadow-xl group-hover:rotate-[360deg] transition-transform duration-700"><Icon name={SERVICE_ICONS[k % 6]} /></div>
                  <h3 className="mt-5 text-xl font-bold text-main">{s.title}</h3>
                  <p className="mt-2 text-muted text-sm">{s.desc}</p>
                  {full && <ul className="mt-4 space-y-1.5 text-sm text-muted">{t.why.items.slice(0, 3).map((w, j) => <li key={j} className="flex gap-2 items-center"><Icon name="check" className="text-gold" /> {w.title}</li>)}</ul>}
                  <Link href="/contact#form" className="mt-4 inline-flex items-center gap-2 text-gold font-semibold text-sm group-hover:gap-3 transition-all">{t.nav.quote} <Icon name="arrow" className="rtl:rotate-180" /></Link>
                </div>
              </Tilt>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Projects({ full = false }: { full?: boolean }) {
  const { c, t } = useSite();
  const items = t.projects.items.map((p, k) => ({ ...p, img: c.images.projects[k % c.images.projects.length], k }));
  const cats = Array.from(new Set(items.map((p) => p.cat)));
  const [filter, setFilter] = useState<string | null>(null);
  const [view, setView] = useState<number | null>(null);
  const track = useRef<HTMLDivElement>(null);
  const scroll = (d: number) => track.current?.scrollBy({ left: d * 380, behavior: "smooth" });
  const shown = filter ? items.filter((p) => p.cat === filter) : items;
  const card = (p: (typeof items)[number]) => (
    <Tilt className="group relative h-[420px] rounded-3xl overflow-hidden shadow-xl cursor-pointer">
      <div onClick={() => setView(p.k)} className="h-full">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={p.img} alt={p.title} className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07142a] via-[#07142a]/30 to-transparent" />
        <div className="pop absolute inset-x-0 bottom-0 p-6 text-white">
          <span className="inline-block rounded-full bg-gold px-3 py-1 text-xs font-semibold text-black">{p.cat}</span>
          <h3 className="mt-3 text-2xl font-bold">{p.title}</h3>
          <div className="mt-1 flex items-center gap-1.5 text-sm text-white/75"><Icon name="pin" /> {p.loc}</div>
          <div className="mt-4 h-0.5 w-0 bg-gold group-hover:w-full transition-all duration-700" />
        </div>
      </div>
    </Tilt>
  );
  return (
    <section className="py-24 px-4 bg-site">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead kicker={t.projects.kicker} title={t.projects.title} text={t.projects.text} />
          {!full ? (
            <div className="flex gap-3 mb-12 reveal">
              <button onClick={() => scroll(-1)} className="h-12 w-12 rounded-full border border-line text-main grid place-items-center hover:bg-gold hover:text-black transition"><Icon name="left" /></button>
              <button onClick={() => scroll(1)} className="h-12 w-12 rounded-full border border-line text-main grid place-items-center hover:bg-gold hover:text-black transition"><Icon name="right" /></button>
              <Link href="/projects" className="btn-outline">{t.projects.all}</Link>
            </div>
          ) : (
            <div className="flex flex-wrap gap-2 mb-12 reveal">
              {[null, ...cats].map((cat) => (
                <button key={cat || "all"} onClick={() => setFilter(cat)} className={`rounded-full px-5 py-2 text-sm font-medium border transition ${filter === cat ? "bg-gold text-black border-transparent" : "border-line text-main hover:border-[var(--gold)]"}`}>{cat || t.projects.filterAll}</button>
              ))}
            </div>
          )}
        </div>
        {full ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
            {shown.map((p) => <div key={p.k} className="fade-up">{card(p)}</div>)}
          </div>
        ) : (
          <div ref={track} className="flex gap-7 overflow-x-auto snap-x snap-mandatory pb-4 [scrollbar-width:none]">
            {items.map((p) => <div key={p.k} className="snap-start shrink-0 w-[85%] sm:w-[360px] reveal zoom">{card(p)}</div>)}
          </div>
        )}
      </div>
      {view !== null && (
        <div className="fixed inset-0 z-[90] bg-black/85 backdrop-blur grid place-items-center p-4 fade-up" onClick={() => setView(null)}>
          <div className="relative max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={items[view].img} alt="" className="w-full max-h-[75vh] object-cover rounded-2xl" />
            <div className="mt-4 text-white"><h3 className="text-2xl font-bold">{items[view].title}</h3><p className="text-white/70">{items[view].cat} · {items[view].loc}</p></div>
            <button onClick={() => setView(null)} className="absolute -top-4 -end-4 h-11 w-11 rounded-full bg-gold text-black grid place-items-center text-xl"><Icon name="close" /></button>
          </div>
        </div>
      )}
    </section>
  );
}

function Why() {
  const { t } = useSite();
  return (
    <section className="relative py-24 px-4 bg-[#0b1f3a] overflow-hidden">
      <div className="absolute inset-0 blueprint" />
      <div className="absolute -top-40 -start-40 h-96 w-96 rounded-full bg-[var(--gold)]/20 blur-3xl" />
      <div className="relative mx-auto max-w-7xl grid lg:grid-cols-3 gap-10">
        <SectionHead kicker={t.why.kicker} title={t.why.title} light />
        <div className="lg:col-span-2 grid sm:grid-cols-2 gap-5">
          {t.why.items.map((w, k) => (
            <div key={k} className="reveal" style={{ transitionDelay: `${k * 80}ms` }}>
              <Tilt className="group glass rounded-2xl p-6 h-full hover:bg-white/15">
                <div className="pop flex gap-4">
                  <div className="shrink-0 h-14 w-14 rounded-full border-2 border-[var(--gold)] text-gold grid place-items-center text-2xl group-hover:bg-gold group-hover:text-black transition"><Icon name={WHY_ICONS[k % 6]} /></div>
                  <div><h3 className="text-lg font-bold text-white">{w.title}</h3><p className="text-sm text-white/70 mt-1">{w.desc}</p></div>
                </div>
              </Tilt>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Process() {
  const { t } = useSite();
  return (
    <section className="py-24 px-4 bg-site2">
      <div className="mx-auto max-w-7xl">
        <SectionHead kicker={t.process.kicker} title={t.process.title} text={t.process.text} center />
        <div className="relative grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="hidden lg:block absolute top-12 inset-x-[12%] h-0.5 border-t-2 border-dashed border-[var(--gold)]/50" />
          {t.process.steps.map((s, k) => (
            <div key={k} className="reveal flip relative text-center group" style={{ transitionDelay: `${k * 150}ms` }}>
              <div className="relative mx-auto h-24 w-24 rounded-full bg-card border-4 border-[var(--gold)] grid place-items-center text-4xl text-gold shadow-xl group-hover:scale-110 group-hover:grad-gold group-hover:text-black transition duration-500">
                <Icon name={STEP_ICONS[k % 4]} />
                <span className="absolute -top-2 -end-2 h-9 w-9 rounded-full bg-[#0b1f3a] text-white text-sm font-bold grid place-items-center">0{k + 1}</span>
              </div>
              <h3 className="mt-6 text-xl font-bold text-main">{s.title}</h3>
              <p className="mt-2 text-muted text-sm">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Afghan() {
  const { t } = useSite();
  const cities = [...t.afghan.cities, ...t.afghan.cities];
  return (
    <section className="py-24 bg-site overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <SectionHead kicker={t.afghan.kicker} title={t.afghan.title} text={t.afghan.text} />
          <div className="grid sm:grid-cols-2 gap-3">
            {t.afghan.features.map((f, k) => (
              <div key={k} className="reveal flex items-center gap-3 rounded-xl bg-site2 p-4 border border-line" style={{ transitionDelay: `${k * 100}ms` }}>
                <span className="grad-gold h-8 w-8 rounded-lg grid place-items-center text-black"><Icon name="check" /></span>
                <span className="font-medium text-main text-sm">{f}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="reveal right relative">
          <div className="relative aspect-square max-w-md mx-auto">
            <div className="absolute inset-0 rounded-full border-2 border-dashed border-[var(--gold)]/40 spin-slow" />
            <div className="absolute inset-10 rounded-full bg-gradient-to-br from-[#0b1f3a] to-[#14365f] shadow-2xl grid place-items-center">
              <div className="text-center text-white">
                <Icon name="pin" className="mx-auto text-6xl text-gold floaty" />
                <div className="mt-3 text-2xl font-extrabold">{t.afghan.cities[0]}</div>
                <div className="text-white/60 text-sm">HQ · Afghanistan</div>
              </div>
            </div>
            {t.afghan.cities.slice(1, 7).map((ct, k) => {
              const a = (k / 6) * Math.PI * 2;
              return (
                <span key={k} className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full bg-card shadow-lg border border-line px-3 py-1.5 text-xs font-semibold text-main" style={{ left: `${50 + Math.cos(a) * 48}%`, top: `${50 + Math.sin(a) * 48}%` }}>{ct}</span>
              );
            })}
          </div>
        </div>
      </div>
      <div className="mt-20 bg-[#0b1f3a] py-5 overflow-hidden">
        <div className="marquee flex w-max gap-12 whitespace-nowrap">
          {cities.map((ct, k) => <span key={k} className="text-2xl font-extrabold text-white/90 flex items-center gap-12">{ct} <span className="text-gold">✦</span></span>)}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const { t } = useSite();
  return (
    <section className="py-24 px-4 bg-site2">
      <div className="mx-auto max-w-7xl">
        <SectionHead kicker={t.testimonials.kicker} title={t.testimonials.title} center />
        <div className="grid md:grid-cols-3 gap-7">
          {t.testimonials.items.map((r, k) => (
            <div key={k} className="reveal" style={{ transitionDelay: `${k * 120}ms` }}>
              <Tilt className="relative h-full rounded-3xl bg-card border border-line p-8 shadow-lg">
                <Icon name="quote" className="absolute top-6 end-6 text-5xl text-[var(--gold)]/30" />
                <div className="flex gap-1 text-gold">{[0, 1, 2, 3, 4].map((s) => <Icon key={s} name="star" fill="currentColor" />)}</div>
                <p className="pop mt-4 text-main leading-relaxed">&ldquo;{r.text}&rdquo;</p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="grad-gold h-12 w-12 rounded-full grid place-items-center font-bold text-black">{r.name.charAt(0)}</div>
                  <div><div className="font-bold text-main">{r.name}</div><div className="text-xs text-muted">{r.role}</div></div>
                </div>
              </Tilt>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Team() {
  const { c, t } = useSite();
  return (
    <section className="py-24 px-4 bg-site2">
      <div className="mx-auto max-w-7xl">
        <SectionHead kicker={t.about.kicker} title={t.pages.team} center />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {t.pages.teamItems.map((m, k) => (
            <div key={k} className="reveal zoom" style={{ transitionDelay: `${k * 100}ms` }}>
              <Tilt className="group rounded-3xl overflow-hidden bg-card border border-line shadow-lg">
                <div className="h-64 overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={c.images.team[k % c.images.team.length]} alt={m.name} className="h-full w-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition duration-700" />
                </div>
                <div className="pop p-5 text-center"><div className="font-bold text-main">{m.name}</div><div className="text-sm text-gold">{m.role}</div></div>
              </Tilt>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  const { c, t } = useSite();
  return (
    <section className="relative py-24 px-4 overflow-hidden">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={c.images.cta} alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#07142a]/95 to-[#0b1f3a]/70" />
      <div className="relative mx-auto max-w-5xl flex flex-col md:flex-row items-center justify-between gap-8 reveal zoom">
        <div className="text-center md:text-start">
          <h2 className="text-3xl md:text-5xl font-extrabold text-white">{t.cta.title}</h2>
          <p className="mt-3 text-white/75 text-lg">{t.cta.text}</p>
        </div>
        <div className="flex gap-3 flex-wrap justify-center">
          <Link href="/contact#form" className="btn-gold text-lg">{t.cta.btn} <Icon name="arrow" className="rtl:rotate-180" /></Link>
          <a href={`https://wa.me/${c.contact.whatsapp}`} target="_blank" rel="noreferrer" className="btn-ghost"><WhatsAppIcon /> WhatsApp</a>
        </div>
      </div>
    </section>
  );
}

function Contact({ withMap = false }: { withMap?: boolean }) {
  const { c, t } = useSite();
  const [f, setF] = useState({ name: "", phone: "", email: "", projectType: "", budget: "", message: "" });
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [err, setErr] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    const r = await fetch("/api/messages", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, kind: f.budget ? "quote" : "contact" }) });
    if (!r.ok) throw new Error((await r.json()).error || "Error");
  };
  const submit = async (wa: boolean) => {
    if (!f.name || (!f.phone && !f.email)) { setErr(`${t.contact.name} + ${t.contact.phone}`); setState("error"); return; }
    setState("sending");
    try {
      await save();
      if (wa) {
        const txt = `*${c.settings.companyName} — New Request*\n${t.contact.name}: ${f.name}\n${t.contact.phone}: ${f.phone}\n${t.contact.email}: ${f.email}\n${t.contact.type}: ${f.projectType}\n${t.contact.budget}: ${f.budget}\n${t.contact.message}: ${f.message}`;
        window.open(`https://wa.me/${c.contact.whatsapp}?text=${encodeURIComponent(txt)}`, "_blank");
      }
      setState("done");
      setF({ name: "", phone: "", email: "", projectType: "", budget: "", message: "" });
    } catch (e) { setErr((e as Error).message); setState("error"); }
  };
  const info = [
    { icon: "phone", label: t.contact.phone, val: `${c.contact.phone1}${c.contact.phone2 ? " | " + c.contact.phone2 : ""}`, href: `tel:${c.contact.phone1.replace(/\s/g, "")}` },
    { icon: "mail", label: t.contact.email, val: c.contact.email, href: `mailto:${c.contact.email}` },
    { icon: "pin", label: t.contact.addressLabel, val: c.contact.address },
    { icon: "clock", label: t.contact.hoursLabel, val: t.contact.hours },
  ];
  return (
    <section id="form" className="py-24 px-4 bg-site scroll-mt-20">
      <div className="mx-auto max-w-7xl grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 reveal left">
          <SectionHead kicker={t.contact.kicker} title={t.contact.title} text={t.contact.text} />
          <div className="space-y-4">
            {info.map((it) => (
              <a key={it.icon} href={it.href} className="group flex gap-4 rounded-2xl border border-line bg-card p-4 hover:border-[var(--gold)] transition">
                <span className="grad-gold h-12 w-12 shrink-0 rounded-xl grid place-items-center text-xl text-black group-hover:scale-110 transition"><Icon name={it.icon} /></span>
                <span><span className="block text-xs text-muted">{it.label}</span><span className="block font-semibold text-main text-sm" dir={it.icon === "phone" ? "ltr" : undefined}>{it.val}</span></span>
              </a>
            ))}
          </div>
        </div>
        <div className="lg:col-span-5 reveal">
          <div className="rounded-3xl bg-[#0b1f3a] p-7 md:p-9 shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 blueprint opacity-60" />
            <div className="relative grid sm:grid-cols-2 gap-4">
              {([["name", "text"], ["phone", "tel"], ["email", "email"]] as const).map(([k, type]) => (
                <label key={k} className={k === "email" ? "" : ""}>
                  <span className="text-xs text-white/70">{t.contact[k]} *</span>
                  <input type={type} value={f[k]} onChange={set(k)} className="mt-1 w-full rounded-xl bg-white/10 border border-white/15 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-[var(--gold)]" placeholder={t.contact[k]} />
                </label>
              ))}
              <label>
                <span className="text-xs text-white/70">{t.contact.type}</span>
                <select value={f.projectType} onChange={set("projectType")} className="mt-1 w-full rounded-xl bg-white/10 border border-white/15 px-4 py-3 text-white outline-none focus:border-[var(--gold)]">
                  <option value="" className="text-black">—</option>
                  {t.contact.types.map((ty) => <option key={ty} className="text-black">{ty}</option>)}
                </select>
              </label>
              <label className="sm:col-span-2">
                <span className="text-xs text-white/70">{t.contact.budget}</span>
                <select value={f.budget} onChange={set("budget")} className="mt-1 w-full rounded-xl bg-white/10 border border-white/15 px-4 py-3 text-white outline-none focus:border-[var(--gold)]">
                  {["", "$10,000+", "$50,000+", "$100,000+", "$500,000+"].map((b) => <option key={b} value={b} className="text-black">{b || "—"}</option>)}
                </select>
              </label>
              <label className="sm:col-span-2">
                <span className="text-xs text-white/70">{t.contact.message}</span>
                <textarea rows={4} value={f.message} onChange={set("message")} className="mt-1 w-full rounded-xl bg-white/10 border border-white/15 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-[var(--gold)]" placeholder={t.contact.message} />
              </label>
              <div className="sm:col-span-2 flex flex-wrap gap-3">
                <button disabled={state === "sending"} onClick={() => submit(false)} className="btn-gold disabled:opacity-60">{state === "sending" ? "..." : t.contact.send} <Icon name="arrow" className="rtl:rotate-180" /></button>
                <button disabled={state === "sending"} onClick={() => submit(true)} className="inline-flex items-center gap-2 rounded-xl bg-[#25d366] px-5 py-3 font-semibold text-white hover:brightness-110 transition"><WhatsAppIcon /> {t.contact.whatsapp}</button>
              </div>
              {state === "done" && <p className="sm:col-span-2 rounded-xl bg-green-500/15 border border-green-500/40 text-green-300 p-3 text-sm fade-up">{t.contact.success}</p>}
              {state === "error" && <p className="sm:col-span-2 rounded-xl bg-red-500/15 border border-red-500/40 text-red-300 p-3 text-sm">{err}</p>}
            </div>
          </div>
        </div>
        <div className="lg:col-span-3 reveal right">
          <Tilt className="relative h-full min-h-[320px] rounded-3xl overflow-hidden shadow-2xl">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={c.images.contact} alt="" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07142a] to-transparent" />
            <p className="pop absolute bottom-6 inset-x-6 text-3xl font-extrabold italic text-grad leading-tight">{t.contact.banner}</p>
          </Tilt>
        </div>
      </div>
      {withMap && (
        <div className="mx-auto max-w-7xl mt-14 reveal zoom">
          <h3 className="text-2xl font-bold text-main mb-4 flex items-center gap-2"><Icon name="pin" className="text-gold" /> {t.contact.map}</h3>
          <div className="rounded-3xl overflow-hidden shadow-2xl border border-line">
            <iframe title="map" src={`https://maps.google.com/maps?q=${encodeURIComponent(c.contact.mapQuery)}&z=14&output=embed`} className="w-full h-[450px]" loading="lazy" />
          </div>
        </div>
      )}
    </section>
  );
}

function Footer() {
  const { c, t } = useSite();
  const links: [string, string][] = [["/", t.nav.home], ["/about", t.nav.about], ["/services", t.nav.services], ["/projects", t.nav.projects], ["/contact", t.nav.contact]];
  return (
    <footer className="bg-[#07142a] text-white px-4 pt-16 pb-6">
      <div className="mx-auto max-w-7xl grid md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <Logo light />
          <p className="mt-4 text-white/60 max-w-sm">{t.footer.about}</p>
          <div className="mt-5 flex gap-3">
            {Object.entries(c.social).filter(([, v]) => v).map(([k, v]) => (
              <a key={k} href={v} target="_blank" rel="noreferrer" aria-label={k} className="h-10 w-10 rounded-full bg-white/10 grid place-items-center hover:bg-gold hover:text-black hover:-translate-y-1 transition">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth={1.8}><path d={SocialPaths[k]} /></svg>
              </a>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-bold text-gold mb-4">{t.footer.quick}</h4>
          <ul className="space-y-2 text-white/70">
            {links.map(([h, l]) => <li key={h}><Link href={h} className="hover:text-gold">{l}</Link></li>)}
            <li><Link href="/admin" className="hover:text-gold inline-flex items-center gap-1.5"><Icon name="lock" /> {t.nav.admin}</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold text-gold mb-4">{t.nav.contact}</h4>
          <ul className="space-y-3 text-white/70 text-sm">
            <li className="flex gap-2" dir="ltr"><Icon name="phone" className="text-gold mt-0.5" /> {c.contact.phone1}</li>
            <li className="flex gap-2"><Icon name="mail" className="text-gold mt-0.5" /> {c.contact.email}</li>
            <li className="flex gap-2"><Icon name="pin" className="text-gold mt-0.5 shrink-0" /> {c.contact.address}</li>
          </ul>
        </div>
      </div>
      <div className="mx-auto max-w-7xl mt-12 pt-6 border-t border-white/10 flex flex-wrap justify-between gap-3 text-sm text-white/50">
        <span>© {new Date().getFullYear()} {c.settings.companyName} {c.settings.companySub}. {t.footer.rights}</span>
        <span>{t.footer.tag1} | {t.footer.tag2}</span>
      </div>
    </footer>
  );
}

/* ---------------- Root ---------------- */
export default function Site({ content, page }: { content: Content; page: PageKey }) {
  const [lang, setLangState] = useState<string>(content.settings.defaultLang || "en");
  const [progress, setProgress] = useState(0);
  const [topBtn, setTopBtn] = useState(false);
  const rtl = LANGS.find((l) => l.code === lang)?.dir === "rtl";
  const t = getT(content, lang);

  useEffect(() => {
    const saved = localStorage.getItem("ha_lang");
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (saved && LANGS.some((l) => l.code === saved)) setLangState(saved);
    if (localStorage.getItem("ha_theme") === "dark") document.documentElement.classList.add("dark");
    if (!sessionStorage.getItem("ha_v")) { sessionStorage.setItem("ha_v", "1"); fetch("/api/stats", { method: "POST" }).catch(() => {}); }
    const on = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(h > 0 ? (window.scrollY / h) * 100 : 0);
      setTopBtn(window.scrollY > 600);
    };
    window.addEventListener("scroll", on);
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = rtl ? "rtl" : "ltr";
  }, [lang, rtl]);

  useEffect(() => {
    if (content.settings.primaryColor) document.documentElement.style.setProperty("--gold", content.settings.primaryColor);
  }, [content.settings.primaryColor]);

  useEffect(() => {
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in"), io.unobserve(e.target))), { threshold: 0.12 });
    document.querySelectorAll(".reveal:not(.in)").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [lang, page]);

  const setLang = useCallback((l: string) => { setLangState(l); localStorage.setItem("ha_lang", l); }, []);

  return (
    <SiteCtx.Provider value={{ c: content, t, lang, setLang, rtl }}>
      <div className="progress-bar" style={{ width: `${progress}%` }} />
      <Navbar page={page} />
      <main className="overflow-x-hidden">
        {page === "home" && (<><Hero /><Stats /><About /><Services /><Projects /><Why /><Process /><Afghan /><Testimonials /><CTA /><Contact /></>)}
        {page === "about" && (<><PageHeader title={t.pages.about} crumb={t.nav.about} /><Stats /><About full /><Why /><Team /><Afghan /><CTA /></>)}
        {page === "services" && (<><PageHeader title={t.pages.services} crumb={t.nav.services} /><Services full /><Process /><Why /><CTA /></>)}
        {page === "projects" && (<><PageHeader title={t.pages.projects} crumb={t.nav.projects} /><Stats /><Projects full /><Testimonials /><CTA /></>)}
        {page === "contact" && (<><PageHeader title={t.pages.contact} crumb={t.nav.contact} /><Contact withMap /></>)}
      </main>
      <Footer />
      <a href={`https://wa.me/${content.contact.whatsapp}`} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="fixed bottom-6 end-6 z-50 h-14 w-14 rounded-full bg-[#25d366] text-white grid place-items-center text-3xl shadow-2xl pulse-ring hover:scale-110 transition"><WhatsAppIcon /></a>
      <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Top" className={`fixed bottom-24 end-7 z-50 h-11 w-11 rounded-full grad-gold text-black grid place-items-center shadow-xl transition ${topBtn ? "opacity-100" : "opacity-0 pointer-events-none"}`}><Icon name="left" className="rotate-90" /></button>
    </SiteCtx.Provider>
  );
}
