"use client";
/* eslint-disable @typescript-eslint/no-explicit-any, @next/next/no-img-element */
import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { LANGS, type Content } from "@/lib/defaults";
import { Icon } from "@/components/site/Icons";

type Msg = { id: number; name: string; phone: string; email: string; projectType: string; budget: string; message: string; kind: string; status: string; createdAt: string };
type MediaItem = { id: number; name: string; mime: string; url: string };
type Tab = "dashboard" | "messages" | "quotes" | "hero" | "branding" | "images" | "contact" | "stats" | "text" | "media" | "account" | "backup";

const INP = "w-full rounded-lg bg-white/5 border border-white/15 px-3 py-2 text-sm text-white placeholder-white/30 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition";
const CARD = "rounded-2xl border border-white/10 bg-white/[.04] backdrop-blur p-5";
const human = (k: string) => k.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase());
const STATUS_COLORS: Record<string, string> = { new: "bg-red-500/20 text-red-300", read: "bg-blue-500/20 text-blue-300", "in progress": "bg-amber-500/20 text-amber-300", replied: "bg-green-500/20 text-green-300", approved: "bg-green-500/20 text-green-300", rejected: "bg-rose-500/20 text-rose-300" };

/* ---------- reusable fields ---------- */
async function uploadFile(file: File): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);
  const r = await fetch("/api/media", { method: "POST", body: fd });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || "Upload failed");
  return j.url;
}

function ImageField({ label, value, onChange, video = false }: { label?: string; value: string; onChange: (v: string) => void; video?: boolean }) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  return (
    <div className="rounded-xl border border-white/10 bg-black/20 p-3">
      {label && <div className="text-xs font-semibold text-white/70 mb-2">{label}</div>}
      <div className="aspect-video rounded-lg overflow-hidden bg-white/5 grid place-items-center mb-2">
        {value ? (video ? <video src={value} className="h-full w-full object-cover" muted autoPlay loop playsInline /> : <img src={value} alt="" className="h-full w-full object-cover" />) : <span className="text-white/30 text-xs">No {video ? "video" : "image"}</span>}
      </div>
      <input className={INP} value={value} onChange={(e) => onChange(e.target.value)} placeholder="https://… or upload" />
      <div className="mt-2 flex gap-2">
        <button type="button" onClick={() => ref.current?.click()} className="flex-1 rounded-lg bg-amber-400 text-black text-xs font-semibold py-2 hover:bg-amber-300">{busy ? "Uploading…" : "Upload"}</button>
        {value && <button type="button" onClick={() => onChange("")} className="rounded-lg bg-white/10 text-white text-xs px-3 hover:bg-red-500/40">Clear</button>}
      </div>
      <input ref={ref} type="file" hidden accept={video ? "video/*" : "image/*"} onChange={async (e) => {
        const f = e.target.files?.[0];
        if (!f) return;
        setBusy(true);
        try { onChange(await uploadFile(f)); } catch (er) { alert((er as Error).message); }
        setBusy(false);
        e.target.value = "";
      }} />
    </div>
  );
}

function ImageList({ label, value, onChange }: { label: string; value: string[]; onChange: (v: string[]) => void }) {
  return (
    <div className={CARD}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-white">{label} <span className="text-white/40 text-sm">({value.length})</span></h3>
        <button onClick={() => onChange([...value, ""])} className="rounded-lg bg-amber-400 text-black text-xs font-semibold px-3 py-1.5">+ Add</button>
      </div>
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {value.map((v, i) => (
          <div key={i} className="relative">
            <ImageField label={`#${i + 1}`} value={v} onChange={(nv) => onChange(value.map((x, j) => (j === i ? nv : x)))} />
            <div className="absolute top-2 end-2 flex gap-1">
              {i > 0 && <button title="Move up" onClick={() => { const a = [...value]; [a[i - 1], a[i]] = [a[i], a[i - 1]]; onChange(a); }} className="h-7 w-7 rounded bg-white/10 text-white text-xs">↑</button>}
              <button title="Remove" onClick={() => onChange(value.filter((_, j) => j !== i))} className="h-7 w-7 rounded bg-red-500/70 text-white text-xs">✕</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function JsonEditor({ value, onChange, path = "" }: { value: any; onChange: (v: any) => void; path?: string }) {
  if (typeof value === "string") {
    return value.length > 70 ? <textarea rows={3} className={INP} value={value} onChange={(e) => onChange(e.target.value)} /> : <input className={INP} value={value} onChange={(e) => onChange(e.target.value)} />;
  }
  if (typeof value === "number") return <input type="number" className={INP} value={value} onChange={(e) => onChange(Number(e.target.value))} />;
  if (typeof value === "boolean") return <input type="checkbox" checked={value} onChange={(e) => onChange(e.target.checked)} className="h-5 w-5 accent-amber-400" />;
  if (Array.isArray(value)) {
    return (
      <div className="space-y-2">
        {value.map((item, i) => (
          <div key={i} className="relative rounded-xl border border-white/10 bg-black/20 p-3 pe-20">
            <div className="absolute top-2 end-2 flex gap-1">
              {i > 0 && <button onClick={() => { const a = [...value]; [a[i - 1], a[i]] = [a[i], a[i - 1]]; onChange(a); }} className="h-7 w-7 rounded bg-white/10 text-white text-xs">↑</button>}
              <button onClick={() => onChange(value.filter((_, j) => j !== i))} className="h-7 w-7 rounded bg-red-500/60 text-white text-xs">✕</button>
            </div>
            <span className="text-[10px] text-amber-300/80 font-bold">#{i + 1}</span>
            <JsonEditor value={item} path={`${path}.${i}`} onChange={(nv) => onChange(value.map((x, j) => (j === i ? nv : x)))} />
          </div>
        ))}
        <button onClick={() => onChange([...value, value.length ? JSON.parse(JSON.stringify(value[value.length - 1])) : ""])} className="rounded-lg border border-dashed border-amber-400/60 text-amber-300 text-xs px-3 py-1.5 hover:bg-amber-400/10">+ Add item</button>
      </div>
    );
  }
  if (value && typeof value === "object") {
    return (
      <div className="grid gap-3">
        {Object.keys(value).map((k) => (
          <label key={k} className="block">
            <span className="text-xs font-semibold text-white/60">{human(k)}</span>
            <div className="mt-1"><JsonEditor value={value[k]} path={`${path}.${k}`} onChange={(nv) => onChange({ ...value, [k]: nv })} /></div>
          </label>
        ))}
      </div>
    );
  }
  return null;
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="text-xs font-semibold text-white/60">{label}</span><div className="mt-1">{children}</div></label>;
}

/* ---------- login ---------- */
function Login({ onDone }: { onDone: () => void }) {
  const [u, setU] = useState("admin");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");
  const go = async () => {
    const r = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: u, password: p }) });
    if (r.ok) onDone(); else setErr((await r.json()).error);
  };
  return (
    <div className="min-h-screen grid place-items-center bg-[#07142a] p-4 relative overflow-hidden">
      <img src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=1800&q=70" alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
      <div className="relative w-full max-w-md rounded-3xl border border-white/15 bg-white/10 backdrop-blur-xl p-8 shadow-2xl fade-up">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 rounded-2xl bg-gradient-to-br from-amber-300 to-amber-500 grid place-items-center text-3xl text-black"><Icon name="lock" /></div>
          <h1 className="mt-4 text-2xl font-extrabold text-white">Admin Panel</h1>
          <p className="text-white/60 text-sm">Hilal Amin Construction Company</p>
        </div>
        <div className="mt-6 space-y-4">
          <Field label="Username"><input className={INP} value={u} onChange={(e) => setU(e.target.value)} /></Field>
          <Field label="Password"><input type="password" className={INP} value={p} onChange={(e) => setP(e.target.value)} onKeyDown={(e) => e.key === "Enter" && go()} /></Field>
          {err && <p className="text-red-300 text-sm">{err}</p>}
          <button onClick={go} className="w-full rounded-xl bg-gradient-to-r from-amber-300 to-amber-500 py-3 font-bold text-black hover:brightness-110">Sign In</button>
          <p className="text-center text-xs text-white/40">Default: admin / admin123 — change it in Account settings.</p>
          <Link href="/" className="block text-center text-sm text-amber-300 hover:underline">← Back to website</Link>
        </div>
      </div>
    </div>
  );
}

/* ---------- main ---------- */
export default function Admin() {
  const [auth, setAuth] = useState<boolean | null>(null);
  const [tab, setTab] = useState<Tab>("dashboard");
  const [content, setContent] = useState<Content | null>(null);
  const [saved, setSaved] = useState<string>("");
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [visits, setVisits] = useState(0);
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [lang, setLang] = useState("en");
  const [section, setSection] = useState("hero");
  const [side, setSide] = useState(false);
  const [toast, setToast] = useState("");
  const [search, setSearch] = useState("");

  const flash = (s: string) => { setToast(s); setTimeout(() => setToast(""), 2500); };
  const loadAll = useCallback(async () => {
    const [c, m, s, md] = await Promise.all([fetch("/api/content").then((r) => r.json()), fetch("/api/messages").then((r) => r.json()), fetch("/api/stats").then((r) => r.json()), fetch("/api/media").then((r) => r.json())]);
    setContent(c); setSaved(JSON.stringify(c)); setDirty(false);
    setMsgs(Array.isArray(m) ? m : []); setVisits(s.visits || 0); setMedia(Array.isArray(md) ? md : []);
  }, []);

  useEffect(() => {
    fetch("/api/auth").then((r) => r.json()).then((j) => setAuth(j.admin));
  }, []);
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (auth) loadAll();
  }, [auth, loadAll]);

  const update = (fn: (c: Content) => Content) => setContent((c) => { if (!c) return c; const n = fn(structuredClone(c)); setDirty(JSON.stringify(n) !== saved); return n; });
  const publish = async () => {
    if (!content) return;
    setSaving(true);
    const r = await fetch("/api/content", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(content) });
    setSaving(false);
    if (r.ok) { setSaved(JSON.stringify(content)); setDirty(false); flash("✓ Published! Website updated."); } else flash("Error saving");
  };
  const setStatus = async (id: number, status: string) => {
    await fetch("/api/messages", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    setMsgs((m) => m.map((x) => (x.id === id ? { ...x, status } : x)));
  };
  const delMsg = async (id: number) => {
    if (!confirm("Delete this message?")) return;
    await fetch(`/api/messages?id=${id}`, { method: "DELETE" });
    setMsgs((m) => m.filter((x) => x.id !== id));
  };

  const chart = useMemo(() => {
    const days = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); return d; });
    return days.map((d) => ({ label: d.toLocaleDateString("en", { month: "short", day: "numeric" }), n: msgs.filter((m) => new Date(m.createdAt).toDateString() === d.toDateString()).length }));
  }, [msgs]);

  if (auth === null) return <div className="min-h-screen grid place-items-center bg-[#07142a] text-white">Loading…</div>;
  if (!auth) return <Login onDone={() => setAuth(true)} />;
  if (!content) return <div className="min-h-screen grid place-items-center bg-[#07142a] text-white">Loading content…</div>;

  const en = content.t.en;
  const quotes = msgs.filter((m) => m.kind === "quote");
  const contacts = msgs.filter((m) => m.kind !== "quote");
  const newCount = (l: Msg[]) => l.filter((m) => m.status === "new").length;

  const nav: [Tab, string, string, number?][] = [
    ["dashboard", "Dashboard", "home"], ["messages", "Messages", "chat", newCount(contacts)], ["quotes", "Quote Requests", "clipboard", newCount(quotes)],
    ["hero", "Hero & Slides", "star"], ["branding", "Logo & Branding", "medal"], ["images", "Pictures", "building"], ["text", "Website Text", "pencil"],
    ["stats", "Numbers / Stats", "crane"], ["contact", "Contact & Social", "phone"], ["media", "Media Library", "globe"], ["account", "Admin Account", "users"], ["backup", "Backup", "shield"],
  ];

  const MsgTable = ({ list }: { list: Msg[] }) => {
    const f = list.filter((m) => !search || JSON.stringify(m).toLowerCase().includes(search.toLowerCase()));
    return (
      <div className={`${CARD} overflow-x-auto`}>
        <table className="w-full text-sm min-w-[800px]">
          <thead><tr className="text-left text-white/50 text-xs border-b border-white/10">{["Name", "Phone", "Email", "Type", "Budget", "Message", "Date", "Status", ""].map((h) => <th key={h} className="py-3 px-2">{h}</th>)}</tr></thead>
          <tbody>
            {f.map((m) => (
              <tr key={m.id} className="border-b border-white/5 hover:bg-white/5 align-top">
                <td className="py-3 px-2 font-semibold text-white">{m.name}</td>
                <td className="px-2 py-3"><a className="text-amber-300" href={`https://wa.me/${m.phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer">{m.phone}</a></td>
                <td className="px-2 py-3 text-white/70">{m.email}</td>
                <td className="px-2 py-3 text-white/70">{m.projectType}</td>
                <td className="px-2 py-3 text-white/70">{m.budget}</td>
                <td className="px-2 py-3 text-white/70 max-w-xs whitespace-pre-wrap">{m.message}</td>
                <td className="px-2 py-3 text-white/50 text-xs">{new Date(m.createdAt).toLocaleString()}</td>
                <td className="px-2 py-3">
                  <select value={m.status} onChange={(e) => setStatus(m.id, e.target.value)} className={`rounded-full px-2 py-1 text-xs border-0 ${STATUS_COLORS[m.status] || "bg-white/10 text-white"}`}>
                    {["new", "read", "in progress", "replied", "approved", "rejected"].map((s) => <option key={s} className="text-black">{s}</option>)}
                  </select>
                </td>
                <td className="px-2 py-3"><button onClick={() => delMsg(m.id)} className="text-red-300 hover:text-red-200">✕</button></td>
              </tr>
            ))}
            {!f.length && <tr><td colSpan={9} className="py-10 text-center text-white/40">No messages yet.</td></tr>}
          </tbody>
        </table>
      </div>
    );
  };

  const max = Math.max(1, ...chart.map((c) => c.n));
  const pts = chart.map((c, i) => `${(i / 6) * 100},${100 - (c.n / max) * 85}`).join(" ");

  return (
    <div className="min-h-screen bg-[#07142a] text-white flex" dir="ltr">
      {/* sidebar */}
      <aside className={`fixed lg:sticky top-0 z-40 h-screen w-64 shrink-0 bg-[#0a1a33] border-r border-white/10 flex flex-col transition-transform ${side ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="p-5 flex items-center gap-3 border-b border-white/10">
          {content.settings.logo ? <img src={content.settings.logo} alt="" className="h-10" /> : <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-amber-300 to-amber-500 grid place-items-center text-black text-xl"><Icon name="crane" /></div>}
          <div><div className="font-extrabold">{content.settings.companyName}</div><div className="text-[9px] tracking-[.2em] text-amber-300">{content.settings.companySub}</div></div>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {nav.map(([k, label, ic, badge]) => (
            <button key={k} onClick={() => { setTab(k); setSide(false); }} className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${tab === k ? "bg-gradient-to-r from-amber-400 to-amber-500 text-black font-semibold shadow-lg shadow-amber-500/20" : "text-white/75 hover:bg-white/5"}`}>
              <Icon name={ic} /> <span className="flex-1 text-left">{label}</span>
              {!!badge && <span className="h-5 min-w-5 px-1 rounded-full bg-amber-400 text-black text-[10px] font-bold grid place-items-center">{badge}</span>}
            </button>
          ))}
        </nav>
        <button onClick={async () => { await fetch("/api/auth", { method: "DELETE" }); setAuth(false); }} className="m-3 rounded-xl border border-white/10 py-2.5 text-sm text-white/70 hover:bg-red-500/20">Log out</button>
      </aside>
      {side && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSide(false)} />}

      <div className="flex-1 min-w-0">
        {/* topbar */}
        <header className="sticky top-0 z-20 bg-[#07142a]/90 backdrop-blur border-b border-white/10 px-4 py-3 flex items-center gap-3">
          <button className="lg:hidden p-2 rounded-lg bg-white/5" onClick={() => setSide(true)}><Icon name="menu" /></button>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search messages…" className={`${INP} max-w-sm hidden sm:block`} />
          <div className="flex-1" />
          {dirty && <span className="text-xs text-amber-300 hidden md:inline">● Unsaved changes</span>}
          <Link href="/" target="_blank" className="rounded-lg border border-amber-400/50 text-amber-300 px-3 py-2 text-sm hover:bg-amber-400/10">View Website ↗</Link>
          <button onClick={publish} disabled={saving || !dirty} className="rounded-lg bg-gradient-to-r from-amber-300 to-amber-500 text-black font-bold px-4 py-2 text-sm disabled:opacity-40">{saving ? "Saving…" : "Publish"}</button>
        </header>

        <main className="p-4 md:p-6 space-y-6">
          {tab === "dashboard" && (
            <>
              <div className="relative rounded-2xl overflow-hidden p-6 md:p-8 border border-white/10">
                <img src={content.images.slides[0]} alt="" className="absolute inset-0 h-full w-full object-cover opacity-30" />
                <div className="absolute inset-0 bg-gradient-to-r from-[#07142a] to-transparent" />
                <div className="relative flex flex-wrap items-center justify-between gap-4">
                  <div><h1 className="text-2xl md:text-3xl font-extrabold">Welcome Back, Admin 👋</h1><p className="text-white/70">Here&apos;s what&apos;s happening with your website today.</p></div>
                  <div className="rounded-xl bg-white/10 backdrop-blur px-4 py-3"><div className="font-semibold">Website Status</div><div className="text-sm text-green-300 flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-green-400 animate-pulse" /> Live</div></div>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
                {[["Total Projects", en.projects.items.length, "building"], ["Total Services", en.services.items.length, "tools"], ["Contact Messages", contacts.length, "chat"], ["Quote Requests", quotes.length, "clipboard"], ["Website Visitors", visits, "users"], ["Languages", LANGS.length, "globe"]].map(([l, v, ic]) => (
                  <div key={l as string} className={`${CARD} hover:-translate-y-1 transition`}>
                    <div className="h-11 w-11 rounded-full border border-amber-400/60 text-amber-300 grid place-items-center text-xl"><Icon name={ic as string} /></div>
                    <div className="mt-3 text-xs text-white/60">{l}</div>
                    <div className="text-3xl font-extrabold">{v as number}</div>
                  </div>
                ))}
              </div>
              <div className="grid xl:grid-cols-3 gap-6">
                <div className={`${CARD} xl:col-span-2`}>
                  <div className="flex justify-between mb-4"><h3 className="font-bold">Recent Projects</h3><button onClick={() => { setTab("text"); setSection("projects"); }} className="text-xs text-amber-300">Manage →</button></div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {en.projects.items.slice(0, 6).map((p: any, i: number) => (
                      <div key={i} className="rounded-xl overflow-hidden bg-black/20 border border-white/10">
                        <img src={content.images.projects[i % content.images.projects.length]} alt="" className="h-28 w-full object-cover" />
                        <div className="p-3"><div className="text-sm font-semibold truncate">{p.title}</div><div className="text-xs text-white/50">{p.cat}</div></div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className={CARD}>
                  <h3 className="font-bold mb-4">Quick Actions</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {([["Edit Slides", "hero"], ["Change Logo", "branding"], ["Edit Text", "text"], ["Pictures", "images"], ["Messages", "messages"], ["Contact Info", "contact"]] as [string, Tab][]).map(([l, tb]) => (
                      <button key={l} onClick={() => setTab(tb)} className="rounded-xl border border-white/10 bg-black/20 py-4 text-sm hover:border-amber-400 hover:text-amber-300 transition">{l}</button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="grid xl:grid-cols-2 gap-6">
                <div className={CARD}>
                  <h3 className="font-bold mb-4">Messages – Last 7 Days</h3>
                  <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-48">
                    <defs><linearGradient id="ag" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#f5a623" stopOpacity=".5" /><stop offset="1" stopColor="#f5a623" stopOpacity="0" /></linearGradient></defs>
                    <polygon points={`0,100 ${pts} 100,100`} fill="url(#ag)" />
                    <polyline points={pts} fill="none" stroke="#f5a623" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
                  </svg>
                  <div className="flex justify-between text-[10px] text-white/50">{chart.map((c) => <span key={c.label}>{c.label} ({c.n})</span>)}</div>
                </div>
                <div className={CARD}>
                  <div className="flex justify-between mb-3"><h3 className="font-bold">Recent Messages</h3><button onClick={() => setTab("messages")} className="text-xs text-amber-300">View all →</button></div>
                  {msgs.slice(0, 6).map((m) => (
                    <div key={m.id} className="flex items-center gap-3 py-2 border-b border-white/5 text-sm">
                      <div className="h-8 w-8 rounded-full bg-amber-400 text-black grid place-items-center font-bold">{m.name[0]}</div>
                      <div className="flex-1 min-w-0"><div className="font-semibold truncate">{m.name}</div><div className="text-xs text-white/50">{m.phone} · {m.projectType}</div></div>
                      <span className={`rounded-full px-2 py-0.5 text-xs ${STATUS_COLORS[m.status] || ""}`}>{m.status}</span>
                    </div>
                  ))}
                  {!msgs.length && <p className="text-white/40 text-sm">No messages yet.</p>}
                </div>
              </div>
            </>
          )}

          {tab === "messages" && <><h2 className="text-2xl font-bold">Contact Messages</h2><MsgTable list={contacts} /></>}
          {tab === "quotes" && <><h2 className="text-2xl font-bold">Quote Requests</h2><MsgTable list={quotes} /></>}

          {tab === "hero" && (
            <>
              <h2 className="text-2xl font-bold">Hero Section — Slideshow / Video</h2>
              <div className={`${CARD} grid md:grid-cols-2 gap-5`}>
                <Field label="Background mode">
                  <div className="flex gap-2">
                    {["slideshow", "video"].map((m) => (
                      <button key={m} onClick={() => update((c) => { c.settings.heroMode = m; return c; })} className={`flex-1 rounded-lg py-2.5 text-sm font-semibold capitalize ${content.settings.heroMode === m ? "bg-amber-400 text-black" : "bg-white/5 text-white/70"}`}>{m}</button>
                    ))}
                  </div>
                </Field>
                <ImageField label="Background Video (mp4)" video value={content.settings.heroVideo} onChange={(v) => update((c) => { c.settings.heroVideo = v; return c; })} />
              </div>
              <ImageList label="Slide Images" value={content.images.slides} onChange={(v) => update((c) => { c.images.slides = v; return c; })} />
              <p className="text-white/50 text-sm">Slide text (titles per language) is under <button className="text-amber-300" onClick={() => { setTab("text"); setSection("hero"); }}>Website Text → hero</button>.</p>
            </>
          )}

          {tab === "branding" && (
            <>
              <h2 className="text-2xl font-bold">Logo & Branding</h2>
              <div className={`${CARD} grid md:grid-cols-2 gap-5`}>
                <ImageField label="Logo image (leave empty for default logo)" value={content.settings.logo} onChange={(v) => update((c) => { c.settings.logo = v; return c; })} />
                <div className="space-y-4">
                  <Field label="Company name"><input className={INP} value={content.settings.companyName} onChange={(e) => update((c) => { c.settings.companyName = e.target.value; return c; })} /></Field>
                  <Field label="Company subtitle"><input className={INP} value={content.settings.companySub} onChange={(e) => update((c) => { c.settings.companySub = e.target.value; return c; })} /></Field>
                  <Field label="Accent color"><input type="color" className="h-11 w-24 rounded bg-transparent" value={content.settings.primaryColor} onChange={(e) => update((c) => { c.settings.primaryColor = e.target.value; return c; })} /></Field>
                  <Field label="Default language">
                    <select className={INP} value={content.settings.defaultLang} onChange={(e) => update((c) => { c.settings.defaultLang = e.target.value; return c; })}>
                      {LANGS.map((l) => <option key={l.code} value={l.code} className="text-black">{l.label}</option>)}
                    </select>
                  </Field>
                </div>
              </div>
            </>
          )}

          {tab === "images" && (
            <>
              <h2 className="text-2xl font-bold">Website Pictures</h2>
              <div className={`${CARD} grid sm:grid-cols-3 gap-4`}>
                {(["about", "cta", "contact"] as const).map((k) => <ImageField key={k} label={`${human(k)} image`} value={content.images[k]} onChange={(v) => update((c) => { c.images[k] = v; return c; })} />)}
              </div>
              <ImageList label="Service Images (in order of services)" value={content.images.services} onChange={(v) => update((c) => { c.images.services = v; return c; })} />
              <ImageList label="Project Images (in order of projects)" value={content.images.projects} onChange={(v) => update((c) => { c.images.projects = v; return c; })} />
              <ImageList label="Team Photos" value={content.images.team} onChange={(v) => update((c) => { c.images.team = v; return c; })} />
            </>
          )}

          {tab === "text" && (
            <>
              <h2 className="text-2xl font-bold">Website Text & Content</h2>
              <div className="flex flex-wrap gap-2">
                {LANGS.map((l) => <button key={l.code} onClick={() => setLang(l.code)} className={`rounded-full px-4 py-2 text-sm ${lang === l.code ? "bg-amber-400 text-black font-bold" : "bg-white/5"}`}>{l.label}</button>)}
              </div>
              <div className="flex flex-wrap gap-2">
                {Object.keys(en).map((s) => <button key={s} onClick={() => setSection(s)} className={`rounded-lg px-3 py-1.5 text-xs capitalize ${section === s ? "bg-white text-black font-bold" : "bg-white/5 text-white/70"}`}>{s}</button>)}
              </div>
              {lang !== "en" && <p className="text-xs text-white/50">Empty / missing fields fall back to English automatically. Add items to services/projects in English first — images follow the same order.</p>}
              <div className={CARD} dir={LANGS.find((l) => l.code === lang)?.dir}>
                <JsonEditor
                  value={(() => { const base = JSON.parse(JSON.stringify((en as any)[section])); const cur = (content.t as any)[lang]?.[section]; return lang === "en" ? base : mergeForEdit(base, cur); })()}
                  onChange={(v) => update((c) => { (c.t as any)[lang] = { ...((c.t as any)[lang] || {}), [section]: v }; return c; })}
                />
              </div>
            </>
          )}

          {tab === "stats" && (
            <>
              <h2 className="text-2xl font-bold">Animated Numbers</h2>
              <div className={`${CARD} grid sm:grid-cols-2 lg:grid-cols-4 gap-4`}>
                {content.stats.map((s, i) => (
                  <div key={i} className="rounded-xl bg-black/20 p-4 space-y-3">
                    <div className="text-xs text-amber-300 font-semibold">{en.stats[i]}</div>
                    <Field label="Value"><input type="number" className={INP} value={s.value} onChange={(e) => update((c) => { c.stats[i].value = Number(e.target.value); return c; })} /></Field>
                    <Field label="Suffix"><input className={INP} value={s.suffix} onChange={(e) => update((c) => { c.stats[i].suffix = e.target.value; return c; })} /></Field>
                  </div>
                ))}
              </div>
              <p className="text-white/50 text-sm">Labels can be translated in Website Text → stats.</p>
            </>
          )}

          {tab === "contact" && (
            <>
              <h2 className="text-2xl font-bold">Contact, WhatsApp & Map</h2>
              <div className={`${CARD} grid md:grid-cols-2 gap-4`}>
                {(Object.keys(content.contact) as (keyof Content["contact"])[]).map((k) => (
                  <Field key={k} label={k === "whatsapp" ? "WhatsApp number (digits only, with country code — form messages go here)" : k === "mapQuery" ? "Map location (address or lat,lng)" : human(k)}>
                    <input className={INP} value={content.contact[k]} onChange={(e) => update((c) => { c.contact[k] = e.target.value; return c; })} />
                  </Field>
                ))}
              </div>
              <div className={CARD}><iframe title="map" className="w-full h-64 rounded-xl" src={`https://maps.google.com/maps?q=${encodeURIComponent(content.contact.mapQuery)}&z=14&output=embed`} /></div>
              <h3 className="text-xl font-bold">Social Links</h3>
              <div className={`${CARD} grid md:grid-cols-2 gap-4`}>
                {(Object.keys(content.social) as (keyof Content["social"])[]).map((k) => (
                  <Field key={k} label={human(k)}><input className={INP} value={content.social[k]} onChange={(e) => update((c) => { c.social[k] = e.target.value; return c; })} /></Field>
                ))}
              </div>
            </>
          )}

          {tab === "media" && (
            <>
              <div className="flex items-center justify-between"><h2 className="text-2xl font-bold">Media Library</h2>
                <label className="rounded-lg bg-amber-400 text-black font-semibold px-4 py-2 text-sm cursor-pointer">Upload<input type="file" hidden accept="image/*,video/*" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { await uploadFile(f); flash("Uploaded"); loadAll(); } catch (er) { alert((er as Error).message); } }} /></label>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-4">
                {media.map((m) => (
                  <div key={m.id} className="rounded-xl overflow-hidden border border-white/10 bg-black/20">
                    {m.mime.startsWith("video") ? <video src={m.url} className="h-28 w-full object-cover" muted /> : <img src={m.url} alt="" className="h-28 w-full object-cover" />}
                    <div className="p-2 text-xs">
                      <div className="truncate">{m.name}</div>
                      <div className="mt-1 flex gap-2">
                        <button onClick={() => { navigator.clipboard.writeText(location.origin + m.url); flash("URL copied"); }} className="text-amber-300">Copy URL</button>
                        <button onClick={async () => { if (confirm("Delete?")) { await fetch(`/api/media?id=${m.id}`, { method: "DELETE" }); loadAll(); } }} className="text-red-300">Delete</button>
                      </div>
                    </div>
                  </div>
                ))}
                {!media.length && <p className="text-white/40">No uploads yet.</p>}
              </div>
            </>
          )}

          {tab === "account" && <Account flash={flash} />}

          {tab === "backup" && (
            <>
              <h2 className="text-2xl font-bold">Backup & Restore</h2>
              <div className={`${CARD} flex flex-wrap gap-3`}>
                <button onClick={() => { const b = new Blob([JSON.stringify(content, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "hilal-amin-backup.json"; a.click(); }} className="rounded-lg bg-amber-400 text-black font-semibold px-4 py-2">Download Backup</button>
                <label className="rounded-lg bg-white/10 px-4 py-2 cursor-pointer">Restore from file<input type="file" hidden accept="application/json" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const j = JSON.parse(await f.text()); update(() => j); flash("Loaded — click Publish to apply"); } catch { alert("Invalid file"); } }} /></label>
                <button onClick={async () => { if (!confirm("Reset ALL content to defaults?")) return; await fetch("/api/content", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reset: true }) }); loadAll(); flash("Reset to defaults"); }} className="rounded-lg bg-red-500/70 px-4 py-2">Reset to Defaults</button>
              </div>
            </>
          )}
        </main>
      </div>
      {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 rounded-xl bg-amber-400 text-black font-semibold px-5 py-3 shadow-2xl fade-up">{toast}</div>}
    </div>
  );
}

function mergeForEdit(base: any, cur: any): any {
  if (cur === undefined || cur === null) return base;
  if (Array.isArray(base)) return Array.isArray(cur) ? base.map((b, i) => (i < cur.length ? mergeForEdit(b, cur[i]) : b)) : base;
  if (base && typeof base === "object") { const o: any = {}; for (const k of Object.keys(base)) o[k] = mergeForEdit(base[k], cur?.[k]); return o; }
  return typeof cur === typeof base ? cur : base;
}

function Account({ flash }: { flash: (s: string) => void }) {
  const [u, setU] = useState("admin");
  const [p, setP] = useState("");
  const [p2, setP2] = useState("");
  return (
    <>
      <h2 className="text-2xl font-bold">Admin Account</h2>
      <div className={`${CARD} max-w-md space-y-4`}>
        <Field label="Username"><input className={INP} value={u} onChange={(e) => setU(e.target.value)} /></Field>
        <Field label="New password"><input type="password" className={INP} value={p} onChange={(e) => setP(e.target.value)} /></Field>
        <Field label="Confirm password"><input type="password" className={INP} value={p2} onChange={(e) => setP2(e.target.value)} /></Field>
        <button onClick={async () => {
          if (p !== p2) return flash("Passwords do not match");
          const r = await fetch("/api/auth", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: u, password: p }) });
          flash(r.ok ? "Credentials updated" : (await r.json()).error);
        }} className="rounded-lg bg-amber-400 text-black font-semibold px-4 py-2">Update Credentials</button>
      </div>
    </>
  );
}
