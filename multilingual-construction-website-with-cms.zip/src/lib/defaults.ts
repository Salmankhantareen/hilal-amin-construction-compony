/* eslint-disable @typescript-eslint/no-explicit-any */
const u = (id: string, w = 1600) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;

export const LANGS = [
  { code: "en", label: "English", dir: "ltr" },
  { code: "ur", label: "اردو", dir: "rtl" },
  { code: "ps", label: "پښتو", dir: "rtl" },
  { code: "fa", label: "دری", dir: "rtl" },
  { code: "ar", label: "العربية", dir: "rtl" },
] as const;
export type Lang = (typeof LANGS)[number]["code"];

const en = {
  nav: { home: "Home", about: "About", services: "Services", projects: "Projects", contact: "Contact", quote: "Get a Quote", admin: "Admin" },
  hero: {
    kicker: "Hilal Amin Construction Company",
    slides: [
      { title: "Building Today.", highlight: "Creating Tomorrow.", sub: "Building quality, strength, and lasting value across Afghanistan." },
      { title: "Strong Foundations.", highlight: "Lasting Legacy.", sub: "Residential, commercial and civil engineering projects delivered with precision." },
      { title: "From Kandahar", highlight: "To Every Province.", sub: "Roads, bridges, schools and homes that move our nation forward." },
    ],
    btn1: "Explore Our Projects", btn2: "Get a Quote", scroll: "Scroll Down",
  },
  stats: ["Projects Completed", "Years Experience", "Skilled Workers", "Provinces Served"],
  about: {
    kicker: "About Us", title: "Building More Than Structures — We Build Trust",
    text: "Hilal Amin Construction Company is a leading construction and development firm based in Kandahar, Afghanistan, committed to delivering high-quality projects that create lasting value. With a focus on innovation, integrity and customer satisfaction, we turn your vision into reality.",
    points: [{ v: "100%", l: "Quality Commitment" }, { v: "250+", l: "Successful Projects" }, { v: "0", l: "Major Incidents" }, { v: "24/7", l: "Support" }],
    missionTitle: "Our Mission", mission: "To build safe, durable and affordable structures that empower Afghan communities and drive economic growth.",
    visionTitle: "Our Vision", vision: "To be the most trusted construction partner in Afghanistan and the region, known for quality and integrity.",
    valuesTitle: "Our Values", values: "Integrity, safety, quality, local employment and respect for culture and environment.",
  },
  services: {
    kicker: "Our Services", title: "What We Offer",
    text: "From residential homes to large commercial complexes and national infrastructure, we provide a full range of construction services tailored to your needs.",
    all: "View All Services",
    items: [
      { title: "Building Construction", desc: "Strong foundations for a better future — multi-storey and RCC structures." },
      { title: "Residential Construction", desc: "Your dream home, our priority. Villas, apartments and housing schemes." },
      { title: "Commercial Construction", desc: "Modern spaces for business growth: markets, offices and hotels." },
      { title: "Civil Engineering", desc: "Roads, bridges, culverts, canals and water supply infrastructure." },
      { title: "Renovation & Remodeling", desc: "Breathe new life into your space with expert renovation." },
      { title: "Project Management", desc: "On time. On budget. With excellence, from design to handover." },
    ],
  },
  projects: {
    kicker: "Our Projects", title: "Featured Projects",
    text: "Explore some of our recent projects and see how we bring ideas to life with quality and precision.",
    all: "View All Projects", filterAll: "All",
    items: [
      { title: "Modern Residential Complex", cat: "Residential", loc: "Kandahar City" },
      { title: "Commercial Trade Tower", cat: "Commercial", loc: "Kabul" },
      { title: "Arghandab Highway Bridge", cat: "Civil Engineering", loc: "Arghandab, Kandahar" },
      { title: "Aino Mina Villas", cat: "Residential", loc: "Aino Mina, Kandahar" },
      { title: "Corporate Office Renovation", cat: "Renovation", loc: "Herat" },
      { title: "Provincial Ring Road", cat: "Civil Engineering", loc: "Helmand" },
    ],
  },
  why: {
    kicker: "Why Choose Us", title: "The Right Partner for Your Project",
    items: [
      { title: "High Quality", desc: "We never compromise on quality materials and workmanship." },
      { title: "Experienced Professionals", desc: "Skilled engineers and workers with proven expertise." },
      { title: "Safety & Standards", desc: "Your safety and international standards are our priority." },
      { title: "Reliable Service", desc: "We deliver what we promise, every time." },
      { title: "On-Time Completion", desc: "We respect your time and deadlines." },
      { title: "Customer Satisfaction", desc: "Your success is our success." },
    ],
  },
  process: {
    kicker: "Our Process", title: "From Plan to Reality",
    text: "A simple, transparent process to ensure your project is completed with excellence.",
    steps: [
      { title: "Consultation", desc: "We understand your needs." },
      { title: "Planning & Design", desc: "We create the best plan for your project." },
      { title: "Construction", desc: "We build with precision and care." },
      { title: "Completion", desc: "We deliver your project on time." },
    ],
  },
  afghan: {
    kicker: "Across Afghanistan", title: "Rebuilding the Nation, One Project at a Time",
    text: "Headquartered in Kandahar, we work in provinces across Afghanistan, employing local talent and using locally sourced materials wherever possible. We understand the climate, terrain and culture — from desert heat to mountain winters.",
    cities: ["Kandahar", "Kabul", "Herat", "Helmand", "Mazar-i-Sharif", "Jalalabad", "Zabul", "Uruzgan"],
    features: ["Earthquake-resistant design", "Climate-adapted materials", "Local workforce employment", "Government & NGO projects"],
  },
  testimonials: {
    kicker: "Testimonials", title: "What Our Clients Say",
    items: [
      { name: "Haji Abdul Rahman", role: "Business Owner, Kandahar", text: "Hilal Amin built our commercial market ahead of schedule with excellent quality. Highly professional team." },
      { name: "Eng. Farid Ahmad", role: "Project Director, NGO", text: "Their attention to safety and standards on our school project was outstanding." },
      { name: "Zahra Mohammadi", role: "Homeowner, Kabul", text: "They turned our dream house into reality. Transparent pricing and great communication." },
    ],
  },
  cta: { title: "Ready to Build Your Next Project?", text: "Let Hilal Amin Construction Company turn your vision into reality.", btn: "Request a Quote" },
  contact: {
    kicker: "Contact Us", title: "Send Us a Message", text: "Get in touch with us. We're here to help with your construction needs.",
    name: "Full Name", phone: "Phone Number", email: "Email Address", type: "Project Type", budget: "Budget", message: "Message",
    send: "Submit Request", whatsapp: "Send via WhatsApp", success: "Thank you! Your message has been received. We will contact you soon.",
    addressLabel: "Address", hoursLabel: "Working Hours", hours: "Sat – Thu: 8:00 AM – 5:00 PM", map: "Find Us on the Map",
    types: ["Residential", "Commercial", "Civil Engineering", "Renovation", "Other"],
    banner: "Together We Build A Better Future",
  },
  pages: {
    about: "About Hilal Amin", services: "Our Services", projects: "Our Projects", contact: "Contact Us",
    team: "Our Leadership", teamItems: [{ name: "Hilal Amin", role: "Founder & CEO" }, { name: "Eng. Ahmad Shah", role: "Chief Engineer" }, { name: "Eng. Naveed Khan", role: "Project Manager" }, { name: "Sayed Karim", role: "Site Supervisor" }],
  },
  footer: { about: "Building quality, strength and lasting value across Afghanistan.", rights: "All rights reserved.", follow: "Follow Us", quick: "Quick Links", tag1: "Building Quality", tag2: "Creating Tomorrow" },
};

export type T = typeof en;
type Deep<X> = { [K in keyof X]?: X[K] extends object ? any : X[K] };

const ur: Deep<T> = {
  nav: { home: "ہوم", about: "ہمارے بارے میں", services: "خدمات", projects: "منصوبے", contact: "رابطہ", quote: "قیمت معلوم کریں", admin: "ایڈمن" },
  hero: {
    kicker: "ہلال امین کنسٹرکشن کمپنی",
    slides: [
      { title: "آج کی تعمیر۔", highlight: "کل کی تخلیق۔", sub: "پورے افغانستان میں معیار، مضبوطی اور پائیدار قدر کی تعمیر۔" },
      { title: "مضبوط بنیادیں۔", highlight: "پائیدار ورثہ۔", sub: "رہائشی، تجارتی اور سول انجینئرنگ منصوبے درستگی کے ساتھ۔" },
      { title: "قندھار سے", highlight: "ہر صوبے تک۔", sub: "سڑکیں، پل، اسکول اور گھر جو قوم کو آگے بڑھاتے ہیں۔" },
    ],
    btn1: "ہمارے منصوبے دیکھیں", btn2: "قیمت معلوم کریں", scroll: "نیچے اسکرول کریں",
  },
  stats: ["مکمل منصوبے", "سال کا تجربہ", "ماہر کارکن", "صوبے"],
  about: {
    kicker: "ہمارے بارے میں", title: "ہم صرف عمارتیں نہیں، اعتماد بناتے ہیں",
    text: "ہلال امین کنسٹرکشن کمپنی قندھار، افغانستان میں قائم ایک معروف تعمیراتی ادارہ ہے جو اعلیٰ معیار کے منصوبے فراہم کرنے کے لیے پرعزم ہے۔ جدت، دیانت اور صارف کی اطمینان کے ساتھ ہم آپ کے خواب کو حقیقت بناتے ہیں۔",
    points: [{ v: "100%", l: "معیار کا عزم" }, { v: "250+", l: "کامیاب منصوبے" }, { v: "0", l: "بڑے حادثات" }, { v: "24/7", l: "سپورٹ" }],
    missionTitle: "ہمارا مشن", mission: "محفوظ، پائیدار اور سستی عمارتیں بنانا جو افغان معاشرے کو مضبوط کریں۔",
    visionTitle: "ہمارا وژن", vision: "افغانستان میں سب سے قابل اعتماد تعمیراتی شراکت دار بننا۔",
    valuesTitle: "ہماری اقدار", values: "دیانت، حفاظت، معیار، مقامی روزگار اور ثقافت کا احترام۔",
  },
  services: {
    kicker: "ہماری خدمات", title: "ہم کیا پیش کرتے ہیں", text: "رہائشی گھروں سے لے کر بڑے تجارتی کمپلیکس تک، ہم مکمل تعمیراتی خدمات فراہم کرتے ہیں۔", all: "تمام خدمات",
    items: [
      { title: "عمارت سازی", desc: "بہتر مستقبل کے لیے مضبوط بنیادیں۔" }, { title: "رہائشی تعمیر", desc: "آپ کا خوابوں کا گھر، ہماری ترجیح۔" },
      { title: "تجارتی تعمیر", desc: "کاروبار کی ترقی کے لیے جدید جگہیں۔" }, { title: "سول انجینئرنگ", desc: "سڑکیں، پل اور پانی کا نظام۔" },
      { title: "تزئین و آرائش", desc: "اپنی جگہ کو نئی زندگی دیں۔" }, { title: "پراجیکٹ مینجمنٹ", desc: "وقت پر، بجٹ میں، بہترین انداز میں۔" },
    ],
  },
  projects: {
    kicker: "ہمارے منصوبے", title: "نمایاں منصوبے", text: "ہمارے حالیہ منصوبے دیکھیں۔", all: "تمام منصوبے", filterAll: "سب",
    items: [
      { title: "جدید رہائشی کمپلیکس", cat: "رہائشی", loc: "قندھار" }, { title: "تجارتی ٹاور", cat: "تجارتی", loc: "کابل" },
      { title: "ارغنداب ہائی وے پل", cat: "سول انجینئرنگ", loc: "ارغنداب" }, { title: "عینو مینہ ولاز", cat: "رہائشی", loc: "عینو مینہ" },
      { title: "دفتر کی تزئین", cat: "تزئین", loc: "ہرات" }, { title: "صوبائی رنگ روڈ", cat: "سول انجینئرنگ", loc: "ہلمند" },
    ],
  },
  why: {
    kicker: "ہمیں کیوں چنیں", title: "آپ کے منصوبے کا صحیح شراکت دار",
    items: [
      { title: "اعلیٰ معیار", desc: "معیار پر کوئی سمجھوتہ نہیں۔" }, { title: "تجربہ کار ماہرین", desc: "ثابت شدہ مہارت والی ٹیم۔" },
      { title: "حفاظت و معیارات", desc: "آپ کی حفاظت ہماری ترجیح۔" }, { title: "قابل اعتماد خدمت", desc: "جو وعدہ کرتے ہیں وہ پورا کرتے ہیں۔" },
      { title: "بروقت تکمیل", desc: "ہم آپ کے وقت کا احترام کرتے ہیں۔" }, { title: "صارف کا اطمینان", desc: "آپ کی کامیابی ہماری کامیابی۔" },
    ],
  },
  process: {
    kicker: "ہمارا طریقہ کار", title: "منصوبے سے حقیقت تک", text: "ایک سادہ اور شفاف عمل۔",
    steps: [{ title: "مشاورت", desc: "ہم آپ کی ضرورت سمجھتے ہیں۔" }, { title: "منصوبہ بندی و ڈیزائن", desc: "بہترین منصوبہ۔" }, { title: "تعمیر", desc: "درستگی اور احتیاط سے۔" }, { title: "تکمیل", desc: "وقت پر حوالگی۔" }],
  },
  afghan: { kicker: "پورے افغانستان میں", title: "ایک ایک منصوبے سے قوم کی تعمیر نو", text: "قندھار میں ہیڈکوارٹر کے ساتھ، ہم افغانستان کے مختلف صوبوں میں مقامی افرادی قوت کے ساتھ کام کرتے ہیں۔", cities: ["قندھار", "کابل", "ہرات", "ہلمند", "مزار شریف", "جلال آباد", "زابل", "ارزگان"], features: ["زلزلہ مزاحم ڈیزائن", "موسم کے مطابق مواد", "مقامی روزگار", "سرکاری و این جی او منصوبے"] },
  testimonials: { kicker: "تاثرات", title: "ہمارے کلائنٹس کیا کہتے ہیں" },
  cta: { title: "اپنا اگلا منصوبہ بنانے کے لیے تیار ہیں؟", text: "ہلال امین کو اپنا خواب حقیقت بنانے دیں۔", btn: "قیمت کی درخواست" },
  contact: { kicker: "رابطہ کریں", title: "ہمیں پیغام بھیجیں", text: "ہم آپ کی مدد کے لیے حاضر ہیں۔", name: "پورا نام", phone: "فون نمبر", email: "ای میل", type: "منصوبے کی قسم", budget: "بجٹ", message: "پیغام", send: "درخواست بھیجیں", whatsapp: "واٹس ایپ پر بھیجیں", success: "شکریہ! آپ کا پیغام موصول ہو گیا۔", addressLabel: "پتہ", hoursLabel: "اوقات کار", hours: "ہفتہ – جمعرات: صبح 8 – شام 5", map: "نقشے پر دیکھیں", types: ["رہائشی", "تجارتی", "سول انجینئرنگ", "تزئین", "دیگر"], banner: "مل کر بہتر مستقبل بنائیں" },
  pages: { about: "ہلال امین کے بارے میں", services: "ہماری خدمات", projects: "ہمارے منصوبے", contact: "رابطہ کریں", team: "ہماری قیادت" },
  footer: { about: "پورے افغانستان میں معیار اور مضبوطی کی تعمیر۔", rights: "جملہ حقوق محفوظ ہیں۔", follow: "ہمیں فالو کریں", quick: "فوری لنکس", tag1: "معیاری تعمیر", tag2: "کل کی تخلیق" },
};

const ps: Deep<T> = {
  nav: { home: "کور", about: "زموږ په اړه", services: "خدمتونه", projects: "پروژې", contact: "اړیکه", quote: "نرخ واخلئ", admin: "اډمین" },
  hero: {
    kicker: "هلال امین ساختماني شرکت",
    slides: [
      { title: "نن جوړونه.", highlight: "سبا رامنځته کول.", sub: "په ټول افغانستان کې کیفیت، ځواک او تلپاتې ارزښت جوړوو." },
      { title: "ټینګې بنسټونه.", highlight: "تلپاتې میراث.", sub: "استوګنیز، سوداګریز او ملکي انجنیري پروژې په دقت سره." },
      { title: "له کندهاره", highlight: "تر هر ولایته.", sub: "سړکونه، پلونه، ښوونځي او کورونه چې هېواد پرمخ بیايي." },
    ],
    btn1: "زموږ پروژې وګورئ", btn2: "نرخ واخلئ", scroll: "لاندې لاړ شئ",
  },
  stats: ["بشپړې پروژې", "کلونه تجربه", "ماهر کارګران", "ولایتونه"],
  about: {
    kicker: "زموږ په اړه", title: "موږ یوازې ودانۍ نه، باور جوړوو",
    text: "هلال امین ساختماني شرکت په کندهار، افغانستان کې یو مخکښ ساختماني شرکت دی چې د لوړ کیفیت پروژو ته ژمن دی. د نوښت، صداقت او پېرودونکي رضایت سره ستاسو خوب په حقیقت بدلوو.",
    points: [{ v: "100%", l: "د کیفیت ژمنتیا" }, { v: "250+", l: "بریالۍ پروژې" }, { v: "0", l: "لویې پېښې" }, { v: "24/7", l: "ملاتړ" }],
    missionTitle: "زموږ ماموریت", mission: "خوندي، دوامداره او ارزانه ودانۍ جوړول چې افغان ټولنې پیاوړې کړي.",
    visionTitle: "زموږ لید", vision: "په افغانستان کې تر ټولو باوري ساختماني شریک کېدل.",
    valuesTitle: "زموږ ارزښتونه", values: "صداقت، خوندیتوب، کیفیت، محلي کار او کلتور ته درناوی.",
  },
  services: {
    kicker: "زموږ خدمتونه", title: "موږ څه وړاندې کوو", text: "له استوګنیزو کورونو تر لویو سوداګریزو ودانیو پورې، بشپړ ساختماني خدمتونه.", all: "ټول خدمتونه",
    items: [
      { title: "ودانۍ جوړونه", desc: "د ښه راتلونکي لپاره ټینګ بنسټونه." }, { title: "استوګنیز ساختمان", desc: "ستاسو د خوب کور، زموږ لومړیتوب." },
      { title: "سوداګریز ساختمان", desc: "د سوداګرۍ لپاره عصري ځایونه." }, { title: "ملکي انجنیري", desc: "سړکونه، پلونه او د اوبو سیسټم." },
      { title: "بیارغونه", desc: "خپل ځای ته نوی ژوند ورکړئ." }, { title: "د پروژې مدیریت", desc: "په وخت، په بودیجه کې، په غوره توګه." },
    ],
  },
  projects: {
    kicker: "زموږ پروژې", title: "ځانګړې پروژې", text: "زموږ وروستۍ پروژې وګورئ.", all: "ټولې پروژې", filterAll: "ټول",
    items: [
      { title: "عصري استوګنیز کمپلکس", cat: "استوګنیز", loc: "کندهار" }, { title: "سوداګریز برج", cat: "سوداګریز", loc: "کابل" },
      { title: "د ارغنداب لویې لارې پل", cat: "ملکي انجنیري", loc: "ارغنداب" }, { title: "عینو مینه ولاګانې", cat: "استوګنیز", loc: "عینو مینه" },
      { title: "د دفتر بیارغونه", cat: "بیارغونه", loc: "هرات" }, { title: "ولایتي حلقوي سړک", cat: "ملکي انجنیري", loc: "هلمند" },
    ],
  },
  why: {
    kicker: "ولې موږ", title: "ستاسو د پروژې سم شریک",
    items: [
      { title: "لوړ کیفیت", desc: "په کیفیت جوړجاړی نه کوو." }, { title: "تجربه لرونکي متخصصین", desc: "ثابت مهارت لرونکې ډله." },
      { title: "خوندیتوب او معیارونه", desc: "ستاسو خوندیتوب زموږ لومړیتوب." }, { title: "باوري خدمت", desc: "څه چې ژمنه کوو، هغه کوو." },
      { title: "پر وخت بشپړول", desc: "ستاسو وخت ته درناوی." }, { title: "د پېرودونکي رضایت", desc: "ستاسو بریا زموږ بریا." },
    ],
  },
  process: {
    kicker: "زموږ پروسه", title: "له پلان تر حقیقت", text: "یوه ساده او روښانه پروسه.",
    steps: [{ title: "مشوره", desc: "ستاسو اړتیا پوهېږو." }, { title: "پلان او ډیزاین", desc: "غوره پلان جوړوو." }, { title: "ساختمان", desc: "په دقت او پاملرنې سره." }, { title: "بشپړول", desc: "پر وخت سپارنه." }],
  },
  afghan: { kicker: "په ټول افغانستان کې", title: "د هېواد بیارغونه، پروژه په پروژه", text: "زموږ مرکزي دفتر په کندهار کې دی او د افغانستان په بېلابېلو ولایتونو کې د محلي کارګرانو سره کار کوو.", cities: ["کندهار", "کابل", "هرات", "هلمند", "مزار شریف", "جلال آباد", "زابل", "اروزګان"], features: ["د زلزلې پر وړاندې ډیزاین", "د اقلیم سره سم مواد", "محلي کار", "دولتي او NGO پروژې"] },
  testimonials: { kicker: "نظرونه", title: "زموږ پېرودونکي څه وايي" },
  cta: { title: "خپلې راتلونکې پروژې ته چمتو یاست؟", text: "هلال امین ته اجازه ورکړئ ستاسو خوب حقیقت کړي.", btn: "د نرخ غوښتنه" },
  contact: { kicker: "اړیکه ونیسئ", title: "موږ ته پیغام ولېږئ", text: "موږ ستاسو د مرستې لپاره دلته یو.", name: "بشپړ نوم", phone: "د تلیفون شمېره", email: "برېښنالیک", type: "د پروژې ډول", budget: "بودیجه", message: "پیغام", send: "غوښتنه ولېږئ", whatsapp: "په واټساپ ولېږئ", success: "مننه! ستاسو پیغام ترلاسه شو.", addressLabel: "پته", hoursLabel: "د کار وخت", hours: "شنبه – پنجشنبه: ۸ سهار – ۵ ماښام", map: "په نقشه کې مو ومومئ", types: ["استوګنیز", "سوداګریز", "ملکي انجنیري", "بیارغونه", "نور"], banner: "یوځای ښه راتلونکی جوړوو" },
  pages: { about: "د هلال امین په اړه", services: "زموږ خدمتونه", projects: "زموږ پروژې", contact: "اړیکه", team: "زموږ مشرتابه" },
  footer: { about: "په ټول افغانستان کې کیفیت او ځواک جوړوو.", rights: "ټول حقونه خوندي دي.", follow: "موږ تعقیب کړئ", quick: "چټک لینکونه", tag1: "کیفیت جوړونه", tag2: "سبا رامنځته کول" },
};

const fa: Deep<T> = {
  nav: { home: "خانه", about: "درباره ما", services: "خدمات", projects: "پروژه‌ها", contact: "تماس", quote: "دریافت قیمت", admin: "مدیریت" },
  hero: { kicker: "شرکت ساختمانی هلال امین", slides: [{ title: "امروز می‌سازیم.", highlight: "فردا را خلق می‌کنیم.", sub: "ساختن کیفیت، استحکام و ارزش ماندگار در سراسر افغانستان." }, { title: "پایه‌های محکم.", highlight: "میراث ماندگار.", sub: "پروژه‌های مسکونی، تجاری و انجنیری ملکی با دقت." }, { title: "از کندهار", highlight: "تا هر ولایت.", sub: "سرک‌ها، پل‌ها، مکاتب و خانه‌ها." }], btn1: "پروژه‌های ما", btn2: "دریافت قیمت", scroll: "پایین بروید" },
  stats: ["پروژه‌های تکمیل‌شده", "سال تجربه", "کارگران ماهر", "ولایات"],
  about: { kicker: "درباره ما", title: "ما فقط ساختمان نمی‌سازیم، اعتماد می‌سازیم", text: "شرکت ساختمانی هلال امین یک شرکت پیشرو در کندهار، افغانستان است که به ارائه پروژه‌های با کیفیت متعهد است.", missionTitle: "ماموریت ما", visionTitle: "دیدگاه ما", valuesTitle: "ارزش‌های ما" },
  services: { kicker: "خدمات ما", title: "آنچه ارائه می‌دهیم", all: "همه خدمات", text: "از خانه‌های مسکونی تا مجتمع‌های بزرگ تجاری." },
  projects: { kicker: "پروژه‌های ما", title: "پروژه‌های برجسته", all: "همه پروژه‌ها", filterAll: "همه", text: "پروژه‌های اخیر ما را ببینید." },
  why: { kicker: "چرا ما", title: "شریک مناسب پروژه شما" },
  process: { kicker: "روند کار", title: "از نقشه تا واقعیت", text: "یک روند ساده و شفاف." },
  afghan: { kicker: "در سراسر افغانستان", title: "بازسازی کشور، پروژه به پروژه" },
  testimonials: { kicker: "نظریات", title: "مشتریان ما چه می‌گویند" },
  cta: { title: "آماده ساخت پروژه بعدی هستید؟", text: "بگذارید هلال امین رویای شما را به واقعیت تبدیل کند.", btn: "درخواست قیمت" },
  contact: { kicker: "تماس با ما", title: "برای ما پیام بفرستید", text: "ما برای کمک اینجا هستیم.", name: "نام کامل", phone: "شماره تلفن", email: "ایمیل", type: "نوع پروژه", budget: "بودجه", message: "پیام", send: "ارسال درخواست", whatsapp: "ارسال با واتساپ", success: "تشکر! پیام شما دریافت شد.", addressLabel: "آدرس", hoursLabel: "ساعات کاری", map: "ما را روی نقشه بیابید", banner: "با هم آینده بهتر می‌سازیم" },
  pages: { about: "درباره هلال امین", services: "خدمات ما", projects: "پروژه‌های ما", contact: "تماس با ما", team: "رهبری ما" },
  footer: { about: "ساختن کیفیت و استحکام در سراسر افغانستان.", rights: "تمام حقوق محفوظ است.", follow: "ما را دنبال کنید", quick: "لینک‌های سریع", tag1: "ساخت با کیفیت", tag2: "خلق فردا" },
};

const ar: Deep<T> = {
  nav: { home: "الرئيسية", about: "من نحن", services: "الخدمات", projects: "المشاريع", contact: "اتصل بنا", quote: "طلب عرض سعر", admin: "الإدارة" },
  hero: { kicker: "شركة هلال أمين للإنشاءات", slides: [{ title: "نبني اليوم.", highlight: "نصنع الغد.", sub: "نبني الجودة والقوة والقيمة الدائمة في جميع أنحاء أفغانستان." }, { title: "أسس قوية.", highlight: "إرث دائم.", sub: "مشاريع سكنية وتجارية وهندسة مدنية بدقة." }, { title: "من قندهار", highlight: "إلى كل ولاية.", sub: "طرق وجسور ومدارس ومنازل." }], btn1: "استكشف مشاريعنا", btn2: "طلب عرض سعر", scroll: "مرر للأسفل" },
  stats: ["مشاريع منجزة", "سنوات خبرة", "عمال مهرة", "ولايات"],
  about: { kicker: "من نحن", title: "نبني أكثر من مبانٍ — نبني الثقة", text: "شركة هلال أمين للإنشاءات شركة رائدة مقرها قندهار، أفغانستان، ملتزمة بتقديم مشاريع عالية الجودة.", missionTitle: "مهمتنا", visionTitle: "رؤيتنا", valuesTitle: "قيمنا" },
  services: { kicker: "خدماتنا", title: "ماذا نقدم", all: "كل الخدمات", text: "من المنازل السكنية إلى المجمعات التجارية الكبيرة." },
  projects: { kicker: "مشاريعنا", title: "مشاريع مميزة", all: "كل المشاريع", filterAll: "الكل", text: "استكشف بعض مشاريعنا الأخيرة." },
  why: { kicker: "لماذا نحن", title: "الشريك المناسب لمشروعك" },
  process: { kicker: "طريقة عملنا", title: "من الخطة إلى الواقع", text: "عملية بسيطة وشفافة." },
  afghan: { kicker: "في أنحاء أفغانستان", title: "نعيد بناء الوطن مشروعاً تلو الآخر" },
  testimonials: { kicker: "آراء العملاء", title: "ماذا يقول عملاؤنا" },
  cta: { title: "مستعد لبناء مشروعك القادم؟", text: "دع هلال أمين يحول رؤيتك إلى واقع.", btn: "اطلب عرض سعر" },
  contact: { kicker: "اتصل بنا", title: "أرسل لنا رسالة", text: "نحن هنا لمساعدتك.", name: "الاسم الكامل", phone: "رقم الهاتف", email: "البريد الإلكتروني", type: "نوع المشروع", budget: "الميزانية", message: "الرسالة", send: "إرسال الطلب", whatsapp: "أرسل عبر واتساب", success: "شكراً! تم استلام رسالتك.", addressLabel: "العنوان", hoursLabel: "ساعات العمل", map: "موقعنا على الخريطة", banner: "معاً نبني مستقبلاً أفضل" },
  pages: { about: "عن هلال أمين", services: "خدماتنا", projects: "مشاريعنا", contact: "اتصل بنا", team: "قيادتنا" },
  footer: { about: "نبني الجودة والقوة في جميع أنحاء أفغانستان.", rights: "جميع الحقوق محفوظة.", follow: "تابعنا", quick: "روابط سريعة", tag1: "بناء الجودة", tag2: "صناعة الغد" },
};

const tr = (items: [string, string][]) => items.map(([title, desc]) => ({ title, desc }));
const testi = (a: [string, string, string][]) => ({ items: a.map(([name, role, text]) => ({ name, role, text })) });
const team = (r: string[]) => ({ teamItems: [{ name: "Hilal Amin", role: r[0] }, { name: "Eng. Ahmad Shah", role: r[1] }, { name: "Eng. Naveed Khan", role: r[2] }, { name: "Sayed Karim", role: r[3] }] });

const urExtra: Deep<T> = {
  testimonials: testi([["حاجی عبدالرحمن", "تاجر، قندھار", "ہلال امین نے ہمارا تجارتی بازار وقت سے پہلے اور بہترین معیار کے ساتھ تعمیر کیا۔ انتہائی پیشہ ور ٹیم۔"], ["انجینئر فرید احمد", "پروجیکٹ ڈائریکٹر، این جی او", "ہمارے اسکول کے منصوبے میں حفاظت اور معیارات پر ان کی توجہ شاندار تھی۔"], ["زہرہ محمدی", "گھر کی مالکن، کابل", "انہوں نے ہمارے خوابوں کا گھر حقیقت بنا دیا۔ شفاف قیمت اور بہترین رابطہ۔"]]),
  pages: team(["بانی و سی ای او", "چیف انجینئر", "پروجیکٹ منیجر", "سائٹ سپروائزر"]),
};
const psExtra: Deep<T> = {
  testimonials: testi([["حاجي عبدالرحمن", "سوداګر، کندهار", "هلال امین زموږ سوداګریز بازار له وخته مخکې او په ښه کیفیت جوړ کړ. ډېره مسلکي ډله."], ["انجنیر فرید احمد", "د پروژې رئیس، NGO", "زموږ د ښوونځي په پروژه کې د خوندیتوب او معیارونو ته یې پاملرنه ډېره ښه وه."], ["زهرا محمدي", "د کور مالکه، کابل", "هغوی زموږ د خوب کور حقیقت کړ. روښانه نرخ او ښه اړیکه."]]),
  pages: team(["بنسټګر او اجرایوي رئیس", "مشر انجنیر", "د پروژې مدیر", "د سایټ څارونکی"]),
};
const faExtra: Deep<T> = {
  about: {
    text: "شرکت ساختمانی هلال امین یک شرکت پیشرو ساختمانی و انکشافی در کندهار، افغانستان است که به ارائه پروژه‌های با کیفیت و ماندگار متعهد است. با تمرکز بر نوآوری، صداقت و رضایت مشتری، رویای شما را به واقعیت تبدیل می‌کنیم.",
    points: [{ v: "100%", l: "تعهد به کیفیت" }, { v: "250+", l: "پروژه موفق" }, { v: "0", l: "حادثه بزرگ" }, { v: "24/7", l: "پشتیبانی" }],
    mission: "ساخت ساختمان‌های ایمن، بادوام و مقرون‌به‌صرفه که جوامع افغان را توانمند سازد.",
    vision: "شریک ساختمانی مورد اعتماد در افغانستان و منطقه، شناخته‌شده با کیفیت و صداقت.",
    values: "صداقت، ایمنی، کیفیت، استخدام محلی و احترام به فرهنگ و محیط زیست.",
  },
  services: { items: tr([["ساخت‌وساز ساختمان", "پایه‌های محکم برای آینده بهتر."], ["ساخت مسکونی", "خانه رویایی شما، اولویت ماست."], ["ساخت تجارتی", "فضاهای مدرن برای رشد تجارت."], ["انجنیری ملکی", "سرک‌ها، پل‌ها و شبکه آبرسانی."], ["ترمیم و بازسازی", "به فضای خود زندگی تازه ببخشید."], ["مدیریت پروژه", "به‌موقع، در بودجه، با کیفیت عالی."]]) },
  projects: { items: [{ title: "مجتمع مسکونی مدرن", cat: "مسکونی", loc: "شهر کندهار" }, { title: "برج تجارتی", cat: "تجارتی", loc: "کابل" }, { title: "پل شاهراه ارغنداب", cat: "انجنیری ملکی", loc: "ارغنداب" }, { title: "ولاهای عینو مینه", cat: "مسکونی", loc: "عینو مینه" }, { title: "بازسازی دفتر", cat: "بازسازی", loc: "هرات" }, { title: "سرک حلقوی ولایتی", cat: "انجنیری ملکی", loc: "هلمند" }] },
  why: { items: tr([["کیفیت بالا", "در کیفیت هیچ‌گاه مصالحه نمی‌کنیم."], ["کارشناسان با تجربه", "تیم ماهر با تخصص ثابت‌شده."], ["ایمنی و معیارها", "ایمنی شما اولویت ماست."], ["خدمات قابل اعتماد", "آنچه وعده می‌دهیم انجام می‌دهیم."], ["تکمیل به‌موقع", "به وقت شما احترام می‌گذاریم."], ["رضایت مشتری", "موفقیت شما موفقیت ماست."]]) },
  process: { steps: tr([["مشوره", "نیاز شما را درک می‌کنیم."], ["طرح و دیزاین", "بهترین طرح را می‌سازیم."], ["ساخت", "با دقت و مراقبت می‌سازیم."], ["تکمیل", "پروژه را به‌موقع تحویل می‌دهیم."]]) },
  afghan: { text: "مرکز ما در کندهار است و در ولایات مختلف افغانستان با نیروی کار محلی و مصالح محلی کار می‌کنیم. اقلیم، زمین و فرهنگ را می‌شناسیم.", cities: ["کندهار", "کابل", "هرات", "هلمند", "مزار شریف", "جلال‌آباد", "زابل", "ارزگان"], features: ["طرح مقاوم در برابر زلزله", "مصالح سازگار با اقلیم", "استخدام نیروی محلی", "پروژه‌های دولتی و موسسات"] },
  testimonials: testi([["حاجی عبدالرحمن", "تاجر، کندهار", "هلال امین بازار تجارتی ما را پیش از وقت و با کیفیت عالی ساخت. تیم بسیار حرفه‌ای."], ["انجنیر فرید احمد", "رئیس پروژه، موسسه", "توجه آن‌ها به ایمنی و معیارها در پروژه مکتب ما فوق‌العاده بود."], ["زهرا محمدی", "صاحب خانه، کابل", "خانه رویایی ما را به واقعیت تبدیل کردند. قیمت شفاف و ارتباط عالی."]]),
  contact: { hours: "شنبه – پنج‌شنبه: ۸ صبح – ۵ عصر", types: ["مسکونی", "تجارتی", "انجنیری ملکی", "بازسازی", "دیگر"] },
  pages: team(["بنیان‌گذار و رئیس", "انجنیر ارشد", "مدیر پروژه", "سرپرست سایت"]),
};
const arExtra: Deep<T> = {
  about: {
    text: "شركة هلال أمين للإنشاءات شركة رائدة في البناء والتطوير مقرها قندهار، أفغانستان، ملتزمة بتقديم مشاريع عالية الجودة تحقق قيمة دائمة. بالابتكار والنزاهة ورضا العملاء نحول رؤيتك إلى واقع.",
    points: [{ v: "100%", l: "الالتزام بالجودة" }, { v: "250+", l: "مشروع ناجح" }, { v: "0", l: "حوادث كبرى" }, { v: "24/7", l: "الدعم" }],
    mission: "بناء منشآت آمنة ومتينة وبأسعار مناسبة تمكّن المجتمعات الأفغانية.",
    vision: "أن نكون الشريك الإنشائي الأكثر ثقة في أفغانستان والمنطقة.",
    values: "النزاهة والسلامة والجودة والتوظيف المحلي واحترام الثقافة والبيئة.",
  },
  services: { items: tr([["أعمال البناء", "أسس قوية لمستقبل أفضل."], ["البناء السكني", "منزل أحلامك أولويتنا."], ["البناء التجاري", "مساحات عصرية لنمو الأعمال."], ["الهندسة المدنية", "طرق وجسور وشبكات مياه."], ["التجديد والترميم", "امنح مساحتك حياة جديدة."], ["إدارة المشاريع", "في الوقت وضمن الميزانية وبتميز."]]) },
  projects: { items: [{ title: "مجمع سكني حديث", cat: "سكني", loc: "مدينة قندهار" }, { title: "برج تجاري", cat: "تجاري", loc: "كابل" }, { title: "جسر طريق أرغنداب", cat: "هندسة مدنية", loc: "أرغنداب" }, { title: "فلل عينو مينا", cat: "سكني", loc: "عينو مينا" }, { title: "تجديد مكاتب", cat: "تجديد", loc: "هرات" }, { title: "الطريق الدائري الإقليمي", cat: "هندسة مدنية", loc: "هلمند" }] },
  why: { items: tr([["جودة عالية", "لا نتنازل أبداً عن الجودة."], ["خبراء محترفون", "فريق ماهر بخبرة مثبتة."], ["السلامة والمعايير", "سلامتك أولويتنا."], ["خدمة موثوقة", "نفي بما نعد."], ["إنجاز في الوقت", "نحترم وقتك ومواعيدك."], ["رضا العملاء", "نجاحك هو نجاحنا."]]) },
  process: { steps: tr([["الاستشارة", "نفهم احتياجاتك."], ["التخطيط والتصميم", "نضع أفضل خطة لمشروعك."], ["التنفيذ", "نبني بدقة وعناية."], ["التسليم", "نسلّم مشروعك في موعده."]]) },
  afghan: { text: "مقرنا الرئيسي في قندهار ونعمل في ولايات أفغانستان بالعمالة والمواد المحلية. نعرف المناخ والتضاريس والثقافة.", cities: ["قندهار", "كابل", "هرات", "هلمند", "مزار شريف", "جلال آباد", "زابل", "أروزغان"], features: ["تصميم مقاوم للزلازل", "مواد تناسب المناخ", "توظيف العمالة المحلية", "مشاريع حكومية ومنظمات"] },
  testimonials: testi([["الحاج عبد الرحمن", "صاحب أعمال، قندهار", "بنت هلال أمين سوقنا التجاري قبل الموعد وبجودة ممتازة. فريق محترف جداً."], ["م. فريد أحمد", "مدير مشروع، منظمة", "كان اهتمامهم بالسلامة والمعايير في مشروع المدرسة رائعاً."], ["زهراء محمدي", "مالكة منزل، كابل", "حولوا منزل أحلامنا إلى حقيقة. أسعار شفافة وتواصل ممتاز."]]),
  contact: { hours: "السبت – الخميس: 8 ص – 5 م", types: ["سكني", "تجاري", "هندسة مدنية", "تجديد", "أخرى"] },
  pages: team(["المؤسس والرئيس التنفيذي", "كبير المهندسين", "مدير المشروع", "مشرف الموقع"]),
};

export const defaultContent = {
  settings: {
    companyName: "HILAL AMIN",
    companySub: "CONSTRUCTION COMPANY",
    logo: "",
    defaultLang: "en",
    primaryColor: "#f5a623",
    heroMode: "slideshow",
    heroVideo: "https://videos.pexels.com/video-files/20568183/20568183-uhd_3840_2160_30fps.mp4",
    showLangSwitcher: true,
  },
  contact: {
    phone1: "+92 300 1234567",
    phone2: "+93 700 560927",
    whatsapp: "923001234567",
    email: "info@hilalamin.com",
    address: "PD11, Aino Mina, Main Road 32, Side Road 17, Kandahar, Afghanistan",
    mapQuery: "Aino Mina, Kandahar, Afghanistan",
  },
  social: { facebook: "#", twitter: "#", linkedin: "#", youtube: "#", instagram: "#" },
  stats: [{ value: 250, suffix: "+" }, { value: 15, suffix: "+" }, { value: 1200, suffix: "+" }, { value: 18, suffix: "" }],
  images: {
    slides: [u("photo-1541888946425-d81bb19240f5", 2000), u("photo-1504307651254-35680f356dfd", 2000), u("photo-1486406146926-c627a92ad1ab", 2000)],
    about: u("photo-1503387762-592deb58ef4e", 1200),
    services: [u("photo-1541888946425-d81bb19240f5", 800), u("photo-1600585154340-be6161a56a0c", 800), u("photo-1486406146926-c627a92ad1ab", 800), u("photo-1545558014-8692077e9b5c", 800), u("photo-1513694203232-719a280e022f", 800), u("photo-1581094794329-c8112a89af12", 800)],
    projects: [u("photo-1487958449943-2429e8be8625", 900), u("photo-1497366216548-37526070297c", 900), u("photo-1545558014-8692077e9b5c", 900), u("photo-1600585154340-be6161a56a0c", 900), u("photo-1513694203232-719a280e022f", 900), u("photo-1621905251189-08b45d6a269e", 900)],
    cta: u("photo-1517089596392-fb9a9033e05b", 2000),
    contact: u("photo-1504307651254-35680f356dfd", 1000),
    team: [u("photo-1560250097-0b93528c311a", 500), u("photo-1507003211169-0a1dd7228f2d", 500), u("photo-1500648767791-00dcc994a43e", 500), u("photo-1472099645785-5658abf4ff4e", 500)],
  },
  t: { en, ur: deepMerge(ur, urExtra, true), ps: deepMerge(ps, psExtra, true), fa: deepMerge(fa, faExtra, true), ar: deepMerge(ar, arExtra, true) } as Record<Lang, any>,
};

export type Content = typeof defaultContent;

function isObj(v: unknown): v is Record<string, any> {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
/** replaceArrays=true: arrays from `over` win entirely; false: merged item-by-item keeping base length */
export function deepMerge<A>(base: A, over: any, replaceArrays = false): A {
  if (Array.isArray(base)) {
    if (!Array.isArray(over)) return base;
    if (replaceArrays) return over as any;
    return base.map((b, i) => (i < over.length ? deepMerge(b, over[i]) : b)) as any;
  }
  if (isObj(base)) {
    if (!isObj(over)) return base;
    const out: any = { ...base };
    for (const k of Object.keys(over)) out[k] = k in base ? deepMerge((base as any)[k], over[k], replaceArrays) : over[k];
    return out;
  }
  return over === undefined || over === null || over === "" ? base : over;
}

export function getT(c: Content, lang: string): T {
  const baseEn = deepMerge(en, c.t.en, true);
  return lang === "en" ? baseEn : deepMerge(baseEn, (c.t as any)[lang] || {});
}
