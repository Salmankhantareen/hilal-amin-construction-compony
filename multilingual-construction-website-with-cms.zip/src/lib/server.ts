import { createHash } from "crypto";
import { cookies } from "next/headers";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { kv } from "@/db/schema";
import { defaultContent, deepMerge, type Content } from "./defaults";

export async function getKV<V>(key: string): Promise<V | null> {
  try {
    const r = await db.select().from(kv).where(eq(kv.key, key)).limit(1);
    return r[0] ? (r[0].value as V) : null;
  } catch {
    return null;
  }
}
export async function setKV(key: string, value: unknown) {
  await db
    .insert(kv)
    .values({ key, value })
    .onConflictDoUpdate({ target: kv.key, set: { value, updatedAt: new Date() } });
}

export async function getContent(): Promise<Content> {
  const stored = await getKV<Partial<Content>>("content");
  return stored ? deepMerge(defaultContent, stored, true) : defaultContent;
}

export async function incrementVisits() {
  try {
    await db.execute(sql`INSERT INTO kv (key, value) VALUES ('visits', '1'::jsonb)
      ON CONFLICT (key) DO UPDATE SET value = to_jsonb((kv.value)::text::int + 1), updated_at = now()`);
  } catch {}
}

const hash = (s: string) => createHash("sha256").update("hilal-amin::" + s).digest("hex");

type AdminCreds = { username: string; passwordHash: string };
export async function getCreds(): Promise<AdminCreds> {
  return (await getKV<AdminCreds>("admin")) || { username: "admin", passwordHash: hash("admin123") };
}
export async function checkLogin(username: string, password: string) {
  const c = await getCreds();
  return c.username === username && c.passwordHash === hash(password) ? hash(c.passwordHash) : null;
}
export async function setCreds(username: string, password: string) {
  await setKV("admin", { username, passwordHash: hash(password) });
  return hash(hash(password));
}
export async function isAdmin() {
  const token = (await cookies()).get("ha_admin")?.value;
  if (!token) return false;
  const c = await getCreds();
  return token === hash(c.passwordHash);
}
