import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { getContent, isAdmin, setKV } from "@/lib/server";
import { defaultContent } from "@/lib/defaults";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(await getContent());
}

export async function PUT(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  await setKV("content", body.reset ? defaultContent : body);
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}
