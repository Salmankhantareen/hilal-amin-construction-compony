import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { isAdmin } from "@/lib/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  const name = String(b.name || "").trim().slice(0, 200);
  if (!name || (!b.phone && !b.email)) return NextResponse.json({ error: "Name and phone or email are required" }, { status: 400 });
  const [row] = await db
    .insert(messages)
    .values({
      name,
      phone: String(b.phone || "").slice(0, 50),
      email: String(b.email || "").slice(0, 200),
      projectType: String(b.projectType || "").slice(0, 100),
      budget: String(b.budget || "").slice(0, 100),
      message: String(b.message || "").slice(0, 5000),
      kind: b.kind === "quote" ? "quote" : "contact",
    })
    .returning();
  return NextResponse.json({ ok: true, id: row.id });
}

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json(await db.select().from(messages).orderBy(desc(messages.createdAt)));
}

export async function PATCH(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id, status } = await req.json();
  await db.update(messages).set({ status: String(status) }).where(eq(messages.id, Number(id)));
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number(new URL(req.url).searchParams.get("id"));
  await db.delete(messages).where(eq(messages.id, id));
  return NextResponse.json({ ok: true });
}
