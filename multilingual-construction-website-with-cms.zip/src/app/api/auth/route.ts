import { NextResponse } from "next/server";
import { checkLogin, isAdmin, setCreds } from "@/lib/server";

const cookieOpts = { httpOnly: true, sameSite: "lax" as const, path: "/", maxAge: 60 * 60 * 24 * 7 };

export async function GET() {
  return NextResponse.json({ admin: await isAdmin() });
}

export async function POST(req: Request) {
  const { username, password } = await req.json();
  const token = await checkLogin(String(username || ""), String(password || ""));
  if (!token) return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
  const res = NextResponse.json({ ok: true });
  res.cookies.set("ha_admin", token, cookieOpts);
  return res;
}

export async function PUT(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { username, password } = await req.json();
  if (!username || !password || String(password).length < 6)
    return NextResponse.json({ error: "Password must be at least 6 characters" }, { status: 400 });
  const token = await setCreds(String(username), String(password));
  const res = NextResponse.json({ ok: true });
  res.cookies.set("ha_admin", token, cookieOpts);
  return res;
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.delete("ha_admin");
  return res;
}
