import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";
import { isAdmin } from "@/lib/server";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db.select({ id: media.id, name: media.name, mime: media.mime, createdAt: media.createdAt }).from(media).orderBy(desc(media.id));
  return NextResponse.json(rows.map((r) => ({ ...r, url: `/api/media/${r.id}` })));
}

export async function POST(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "No file" }, { status: 400 });
  if (file.size > 25 * 1024 * 1024) return NextResponse.json({ error: "File too large (max 25MB)" }, { status: 400 });
  const data = Buffer.from(await file.arrayBuffer()).toString("base64");
  const [row] = await db.insert(media).values({ name: file.name, mime: file.type || "application/octet-stream", data }).returning({ id: media.id });
  return NextResponse.json({ id: row.id, url: `/api/media/${row.id}` });
}

export async function DELETE(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number(new URL(req.url).searchParams.get("id"));
  await db.delete(media).where(eq(media.id, id));
  return NextResponse.json({ ok: true });
}
