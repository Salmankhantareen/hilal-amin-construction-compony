import { NextResponse } from "next/server";
import { getKV, incrementVisits, isAdmin } from "@/lib/server";

export const dynamic = "force-dynamic";

export async function POST() {
  await incrementVisits();
  return NextResponse.json({ ok: true });
}

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ visits: Number((await getKV<number>("visits")) || 0) });
}
