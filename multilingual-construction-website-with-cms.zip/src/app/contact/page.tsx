import Site from "@/components/site/Site";
import { getContent } from "@/lib/server";

export const dynamic = "force-dynamic";
export const metadata = { title: "Contact | Hilal Amin Construction Company" };

export default async function Page() {
  return <Site content={await getContent()} page="contact" />;
}
