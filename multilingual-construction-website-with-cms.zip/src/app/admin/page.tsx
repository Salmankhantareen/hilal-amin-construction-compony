import Admin from "@/components/admin/Admin";

export const metadata = { title: "Admin Panel | Hilal Amin Construction" };

export default function Page() {
  return <Admin />;
}
