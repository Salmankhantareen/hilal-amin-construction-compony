import Site from "@/components/site/Site";
import { getContent } from "@/lib/server";

export const dynamic = "force-dynamic";

export default async function Page() {
  return <Site content={await getContent()} page="home" />;
}
